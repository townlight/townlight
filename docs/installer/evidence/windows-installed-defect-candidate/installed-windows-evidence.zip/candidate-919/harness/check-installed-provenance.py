import json,hashlib
from pathlib import Path
out=Path(r'C:\TownlightEvidence')
identity=json.loads((out/'candidate-installed.json').read_text(encoding='utf-8-sig'))
root=Path(identity['payload'])
lock=json.loads((root/'runtime-payload-lock.json').read_text())
rows=[]
assert lock['umbrella_source_commit']==identity['source_commit']
for profile in ('planning','permitting','inspections'):
    name=f'{profile}-candidate-provenance.json';path=root/'python'/name
    payload=next(p for p in lock['payloads'] if p['source_dir']=='python')
    entry=next(f for f in payload['required_files'] if f['path']==name)
    provenance=json.loads(path.read_text())
    sha=hashlib.sha256(path.read_bytes()).hexdigest()
    passed=sha==entry['sha256'] and path.stat().st_size==entry['size_bytes'] and provenance['profile']==profile+'-preview' and provenance['build_profile']=='inspections-preview' and provenance['umbrella_source_commit']==identity['source_commit']
    rows.append(dict(profile=profile,sha256=sha,passed=passed,bytes=path.stat().st_size))
result=dict(passed=all(r['passed'] for r in rows),source=identity['source_commit'],rows=rows,method='Read exact installed payload files; independently recompute hashes and compare locked provenance identities')
(out/'installed-profile-provenance.json').write_text(json.dumps(result,indent=2))
assert result['passed'],result
