﻿$ErrorActionPreference='Stop'
& 'C:\TownlightCandidate\invoke-installed-webview.ps1' -JavaScriptPath 'C:\TownlightCandidate\commands\130-full-catalog.js' -TimeoutMinutes 25 | Set-Content -Encoding UTF8 'C:\TownlightEvidence\130-full-catalog.json'
