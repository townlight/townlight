﻿$ErrorActionPreference='Stop'
& 'C:\TownlightCandidate\invoke-installed-webview.ps1' -JavaScriptPath 'C:\TownlightCandidate\commands\102-observer.js' -TimeoutMinutes 25 | Set-Content -Encoding UTF8 'C:\TownlightEvidence\102-observer.json'
