﻿$ErrorActionPreference='Stop'
if($env:USERNAME -ne 'WDAGUtilityAccount'){throw 'Wrong disposable account'}
$installed=Get-Content -LiteralPath C:\TownlightEvidence\candidate-installed.json -Raw|ConvertFrom-Json
$expected=Get-Content -LiteralPath C:\TownlightCandidate\candidate-expected.json -Raw|ConvertFrom-Json
if($installed.product_code -ne $expected.product_code){throw 'Candidate identity mismatch'}
$exe=Join-Path $installed.install_dir 'townlight-desktop.exe'
$remaining=@(Get-CimInstance Win32_Process|Where-Object {$_.ExecutablePath -eq $exe})
$closeDeadline=(Get-Date).AddSeconds(30)
while($remaining.Count -and (Get-Date) -lt $closeDeadline){Start-Sleep -Seconds 1;$remaining=@(Get-CimInstance Win32_Process|Where-Object {$_.ExecutablePath -eq $exe})}
@{at=[datetime]::UtcNow.ToString('o');remaining=@($remaining|Select-Object ProcessId,ExecutablePath)}|ConvertTo-Json|Set-Content C:\TownlightEvidence\graceful-desktop-terminal-readback.json
if($remaining.Count){throw 'Desktop still running; no forced termination or MSI removal attempted'}
$product=$installed.product_code
$started=[datetime]::UtcNow.ToString('o')
$p=Start-Process msiexec.exe -ArgumentList @('/x',$product,'/qn','/norestart','/l*v','C:\TownlightEvidence\audit-uninstall.log') -PassThru -Wait
$exit=$p.ExitCode
if($null -eq $exit){$terminal=Get-Content -LiteralPath C:\TownlightEvidence\audit-uninstall.log -Tail 80|Select-String 'MainEngineThread is returning (\d+)'|Select-Object -Last 1;if($terminal){$exit=[int]$terminal.Matches[0].Groups[1].Value}}
$registered=(Test-Path ('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\'+$product)) -or (Test-Path ('HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\'+$product)) -or (Test-Path ('HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\'+$product))
@{started=$started;finished=[datetime]::UtcNow.ToString('o');exit_code=$exit;registered=$registered;desktop_file_remaining=Test-Path -LiteralPath $exe;profile_files=@(Get-ChildItem -LiteralPath 'C:\Users\WDAGUtilityAccount\AppData\Local\CivicSuite' -Recurse -File -ErrorAction SilentlyContinue|Select-Object FullName,Length);passed=($exit -in @(0,3010) -and !$registered -and !(Test-Path -LiteralPath $exe))}|ConvertTo-Json -Depth 6|Set-Content -Encoding UTF8 C:\TownlightEvidence\msi-uninstall-verification.json
if($exit -notin @(0,3010) -or $registered){throw "MSI uninstall unresolved: exit=$exit registered=$registered"}
