﻿$ErrorActionPreference='Stop'
if($env:USERNAME -ne 'WDAGUtilityAccount'){throw 'Guest only'}
$profileRoot=Join-Path $env:LOCALAPPDATA 'CivicSuite'
$base=Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'Townlight Backups'
$backup=Get-ChildItem -LiteralPath $base -Directory -Filter 'townlight-final-uninstall-backup-*'|Sort-Object LastWriteTimeUtc -Descending|Select-Object -First 1
if(!$backup){throw 'Final backup absent'}
$manifest=Join-Path $backup.FullName 'backup-manifest.json'
$checks=[ordered]@{final_backup_manifest_present=(Test-Path -LiteralPath $manifest);data_removed=!(Test-Path -LiteralPath (Join-Path $profileRoot 'Data'));config_removed=!(Test-Path -LiteralPath (Join-Path $profileRoot 'config'))}
$pass=$checks.final_backup_manifest_present -and $checks.data_removed -and $checks.config_removed
[ordered]@{passed=$pass;checks=$checks;backup=$backup.FullName;manifest_sha256=(Get-FileHash -LiteralPath $manifest).Hash;at=[datetime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content -LiteralPath C:\TownlightEvidence\prepare-uninstall-verification.json -Encoding utf8
if(!$pass){throw 'Prepared uninstall filesystem verification failed'}
