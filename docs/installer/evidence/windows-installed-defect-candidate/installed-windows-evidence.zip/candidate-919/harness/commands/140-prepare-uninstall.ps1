﻿$ErrorActionPreference='Stop'
if($env:USERNAME -ne 'WDAGUtilityAccount'){throw 'Disposable guest only'}
$out='C:\TownlightEvidence'
$done=Get-Content -LiteralPath "$out\070-final-installed-proof.json" -Raw|ConvertFrom-Json
if(!$done.passed){throw 'Fresh installed proof incomplete'}
$installed=Get-Content -LiteralPath "$out\candidate-installed.json" -Raw|ConvertFrom-Json
$exe=Join-Path $installed.install_dir 'townlight-desktop.exe'
$sha=(Get-FileHash -LiteralPath $exe).Hash
$sig=Get-AuthenticodeSignature -LiteralPath $exe
if($sha -ne $installed.desktop_sha256 -or $sig.Status -ne 'Valid'){throw 'Installed binary changed'}
[ordered]@{passed=$true;sha256=$sha;publisher=$sig.SignerCertificate.Subject;timestamp=$sig.TimeStamperCertificate.Subject;at=[datetime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content -LiteralPath "$out\final-installed-binary.json" -Encoding utf8
$js=Join-Path $env:TEMP 'candidate-prepare-uninstall.js'
[IO.File]::WriteAllText($js,'(async()=>{const a=window.audit;await a.nav("health");await a.sleep(6000);const row=await a.test("uninstall/prepare-final-backup-and-profile-removal",()=>a.click("[data-supervisor-action=\"uninstall\"]",{timeout:300000}),()=>!document.querySelector(".action-result.blocked"));return{passed:row.pass,row,app:await a.native("get_app_state"),results:[...document.querySelectorAll(".action-result")].map(e=>e.textContent)};})()')
& C:\TownlightCandidate\invoke-installed-webview.ps1 -JavaScriptPath $js -TimeoutMinutes 8|Set-Content -LiteralPath "$out\candidate-prepare-uninstall.json" -Encoding utf8
