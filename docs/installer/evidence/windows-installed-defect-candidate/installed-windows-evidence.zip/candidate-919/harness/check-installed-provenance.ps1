﻿$ErrorActionPreference='Stop'
if($env:USERNAME -ne 'WDAGUtilityAccount'){throw 'Guest only'}
$installed=Get-Content -LiteralPath C:\TownlightEvidence\candidate-installed.json -Raw|ConvertFrom-Json
& (Join-Path $installed.payload 'python\python.exe') -I -B C:\TownlightCandidate\check-installed-provenance.py
if($LASTEXITCODE){throw 'Installed profile provenance check failed'}
