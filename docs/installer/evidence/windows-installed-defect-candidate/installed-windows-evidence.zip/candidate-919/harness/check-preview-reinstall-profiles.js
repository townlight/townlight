(async()=>{
 const a=window.audit,rows=[],f=a.fixture,app=()=>a.native('get_app_state');
 const priorAttempt=a.records.filter(r=>r.id.startsWith('D7/'));
 for(const [id,profile]of [['townlight_planning','planning-preview'],['townlight_permitting','permitting-preview'],['townlight_inspections','inspections-preview']]){
  await a.nav('settings');await a.sleep(5500);
  rows.push(await a.test('D7/reinstall-with-supported-profile/'+id,async()=>{
   await a.click('[data-module-profile-id="'+profile+'"]',{confirm:false});
   await a.click('[data-first-run-action="select-modules"][data-step-id="modules"]',{timeout:300000});
  },async()=>{const s=await app();return s.module_selection.profile_id===profile&&s.modules.find(m=>m.id===id).installed;}));
  if(!rows.at(-1).pass)throw Error(JSON.stringify(rows.at(-1)));
 }
 await a.ensureRuntime();const state=await a.native('suite_domain_request',{request:{operation:'state'}}),request=state.records_requests.find(r=>r.request_id===f.records.request_id);
 rows.push(await a.test('D7/reinstalled-profile-retains-linked-Records',async()=>{},()=>!!request&&request.summary==='Synthetic subset profile retention'));
 return {rows,request,priorAttempt,method:'Preview products reinstall through their explicitly supported matching profiles; individual Install control is unavailable outside those profiles.'};
})()
