## Demo Fixture Identity
Municipality: Town of Redstone Valley (Fictional)
Fixture: redstone-valley-records-demo v1.0.1
Fixture SHA-256: d9aaa79403cfca2711e8031439fbab8bf9f70a20b8afc293faef8edd683ffbd6
Watermark: SYNTHETIC DEMONSTRATION DATA - NOT A REAL MUNICIPAL RECORD

# Records Response

Tracking number: REQ-0001
Requester: Fictional Audit Requester
Contact: No contact recorded.
Submitted via: Staff intake
Deadline: 2026-11-09
Deadline basis: Audit manually set deadline Rule: Synthetic three working days; received 2026-11-04; calculated as 3 business days from receipt; weekends are automatically skipped; city/state holidays must be checked by staff.
Assigned to: Fictional Records Officer
Status: release package built
Fee estimate: $0.00 waived: Synthetic audit waiver

## Request
Synthetic comprehensive UI audit request

## Request Timeline
  Id: records-timeline-5ba4e52e-76f7-4a6a-b54b-f860cf71e167
  Action: intake
  Actor: records staff
  Note: Staff created request REQ-0001 with deadline 2026-12-15.
  Created At Unix Seconds: 1793825763
  Id: records-timeline-7054f89b-0230-410e-8a8f-ed64f5edf157
  Action: deadline reviewed
  Actor: records staff
  Note: Response deadline set to 2026-12-16; basis: Audit manually set deadline.
  Created At Unix Seconds: 1793825764
  Id: records-timeline-1743fb64-10fc-4fb2-8109-d4e7f70b3cf9
  Action: deadline calculated
  Actor: records staff
  Note: Synthetic three working days: received 2026-11-04; due 2026-11-09. Audit manually set deadline Rule: Synthetic three working days; received 2026-11-04; calculated as 3 business days from receipt; weekends are automatically skipped; city/state holidays must be checked by staff.
  Created At Unix Seconds: 1793825764
  Id: records-timeline-6e17ca65-ba84-4a21-a11e-c70e689aa9c6
  Action: assigned
  Actor: records staff
  Note: Assigned to Fictional Records Officer.
  Created At Unix Seconds: 1793825765
  Id: records-timeline-c0d39a64-674e-4955-988f-01ae648a9857
  Action: clarification requested
  Actor: records staff
  Note: Synthetic date-range clarification
  Created At Unix Seconds: 1793825766
  Id: records-timeline-0b233978-50ae-4b0f-93b8-9d299227e8f5
  Action: search recorded
  Actor: records staff
  Note: Synthetic file cabinet checked Citation: Audit source one.
  Created At Unix Seconds: 1793825767
  Id: records-timeline-a614f27b-c575-4832-b4e4-7e69937cf896
  Action: search session recorded
  Actor: records staff
  Note: Synthetic audit source across Synthetic local folder; result Audit responsive record.
  Created At Unix Seconds: 1793825768
  Id: records-timeline-a87d8986-a66c-45d5-8797-ddca0c7ff44b
  Action: exemption review recorded
  Actor: records staff
  Note: Synthetic exemption review note
  Created At Unix Seconds: 1793825769
  Id: records-timeline-5507c32c-4fed-473c-996c-64a099bd28b7
  Action: exemption decision recorded
  Actor: records staff
  Note: release decision for Audit page 1: Synthetic staff finding under Synthetic policy basis.
  Created At Unix Seconds: 1793825770
  Id: records-timeline-d54350ba-2305-4ffe-b227-12a5c270318c
  Action: fee estimate saved
  Actor: records staff
  Note: 12.50
  Created At Unix Seconds: 1793825771
  Id: records-timeline-9a9a00e0-f041-4d6f-9058-3268769ab8d0
  Action: fee line added
  Actor: records staff
  Note: Synthetic copying: $2.50 under Fictional fee schedule
  Created At Unix Seconds: 1793825772
  Id: records-timeline-349edb6b-b08e-4c34-aa63-c402c5ae6f8f
  Action: fee waived
  Actor: records staff
  Note: Synthetic audit waiver
  Created At Unix Seconds: 1793825773
  Id: records-timeline-a2a1b2f5-de7e-4912-b04e-6435e5cde28c
  Action: message sent
  Actor: records staff
  Note: Synthetic requester-visible staff message
  Created At Unix Seconds: 1793825774
  Id: records-timeline-97acff8c-c59d-442d-8bd2-6d9615e94385
  Action: document attached
  Actor: records staff
  Note: Attached Synthetic original from fixture-source.txt; sha256 31e389467c99f5508e53974daa52c9f36b53045e6b4d3ef7ef5be1be95e9318a.
  Created At Unix Seconds: 1793825775
  Id: records-timeline-3b52c521-418b-4715-9341-cf290f976475
  Action: release copy attached
  Actor: records staff
  Note: release-ready copy attached for Synthetic original; sha256 31e389467c99f5508e53974daa52c9f36b53045e6b4d3ef7ef5be1be95e9318a. Synthetic reviewed release copy
  Created At Unix Seconds: 1793825775
  Id: records-timeline-72f60a33-3ee5-4575-8d72-9adfa09e9841
  Action: response drafted
  Actor: records staff
  Note: Draft response saved with citation Audit source one.
  Created At Unix Seconds: 1793825776
  Id: records-timeline-bde26af5-5049-448d-8c3e-1d27b22c4c96
  Action: response approved
  Actor: records staff
  Note: Synthetic human review approval
  Created At Unix Seconds: 1793825777
  Id: records-timeline-40aec71d-73ed-45a7-900d-48d37ec900df
  Action: release package built
  Actor: records staff
  Note: Release package manifest written to C:\Users\WDAGUtilityAccount\AppData\Local\CivicSuite\Data\exports\records\records-release-package-be8e49b7-8979-44eb-8181-99360309bdaa.md; sha256 d75b3f5cc38b1a820025a98f0b5e450e858003a340cf675436bfb851738b97b8.
  Created At Unix Seconds: 1793825778

## Request Messages
  Id: records-message-fbfd093d-46ca-4824-be81-fb5af58b8b07
  Author: Records staff
  Author Role: staff
  Body: Synthetic requester-visible staff message
  Visibility: requester thread
  Created At Unix Seconds: 1793825774

## Request Documents
  Id: records-document-7baeea28-06b3-406f-9b29-0ff3db10a007
  Attachment Id: 7baeea28-06b3-406f-9b29-0ff3db10a007
  Title: Synthetic original
  Original Path: C:\TownlightCandidate\fixture-source.txt
  Stored Path: C:\Users\WDAGUtilityAccount\AppData\Local\CivicSuite\Data\files\records\staged\f73b5b7c-cac0-4b2c-b6aa-b99a862a7792.txt
  Citation: Audit original
  Sha256: 31e389467c99f5508e53974daa52c9f36b53045e6b4d3ef7ef5be1be95e9318a
  Size Bytes: 71
  Status: release-ready copy attached
  Added By: records staff
  Created At Unix Seconds: 1793825775
  Release Original Path: C:\TownlightCandidate\fixture-source.txt
  Release Stored Path: C:\Users\WDAGUtilityAccount\AppData\Local\CivicSuite\Data\files\records\staged\e75f4883-b357-4467-bfa8-beb6fbf36164.txt
  Release File Name: fixture-source.txt
  Release Sha256: 31e389467c99f5508e53974daa52c9f36b53045e6b4d3ef7ef5be1be95e9318a
  Release Size Bytes: 71
  Release Status: release-ready copy
  Release Note: Synthetic reviewed release copy
  Release Added By: Fictional reviewer
  Release Added At Unix Seconds: 1793825775

## Release Packages
  Id: records-release-package-be8e49b7-8979-44eb-8181-99360309bdaa
  Export Path: C:\Users\WDAGUtilityAccount\AppData\Local\CivicSuite\Data\exports\records\records-release-package-be8e49b7-8979-44eb-8181-99360309bdaa.md
  Package Hash: d75b3f5cc38b1a820025a98f0b5e450e858003a340cf675436bfb851738b97b8
  Document Count: 1
  Release Artifact Count: 1
  Search Session Count: 1
  Release Count: 1
  Redacted Count: 0
  Exempt Count: 0
  Created At Unix Seconds: 1793825778

## Fee Review
  Id: records-fee-line-aee208ca-29d3-4b9d-9bff-eaa616c63400
  Description: Synthetic copying
  Schedule Basis: Fictional fee schedule
  Amount Cents: 250
  Created At Unix Seconds: 1793825772

## Clarification Notes
- Synthetic date-range clarification

## Search Notes
- Synthetic file cabinet checked

## Search Sessions
  Id: records-search-session-327737c8-0460-44cd-a3d6-405f00ebb876
  Query: Synthetic audit source
  Locations: Synthetic local folder
  Reviewer: Fictional Records Officer
  Results: [{'id': 'records-search-result-4d1948de-6d27-476f-b46c-1048f2b53f4d', 'title': 'Audit responsive record', 'citation': 'Audit citation', 'summary': 'Synthetic responsive result', 'status': 'responsive'}]
  Created At Unix Seconds: 1793825768

## Exemption Review Notes
- Synthetic exemption review note

## Exemption Decisions
  Id: records-exemption-decision-f9387485-b8a1-42fb-b27c-f6162c8bf5f6
  Source: Audit page 1
  Kind: Synthetic category
  Finding: Synthetic staff finding
  Decision: release
  Basis: Synthetic policy basis
  Reviewer: Fictional reviewer
  Created At Unix Seconds: 1793825770

## Citations
- Audit source one
- Audit citation
- Synthetic policy basis
- Audit original
- Audit source one

## Approval Notes
- Synthetic human review approval

Fee waiver: Synthetic audit waiver

## Approved Response
Synthetic responsive letter. Audit source one.
