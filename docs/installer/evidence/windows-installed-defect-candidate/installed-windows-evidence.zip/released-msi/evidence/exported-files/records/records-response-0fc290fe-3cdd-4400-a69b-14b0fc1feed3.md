## Demo Fixture Identity
Municipality: Town of Redstone Valley (Fictional)
Fixture: redstone-valley-records-demo v1.0.1
Fixture SHA-256: d9aaa79403cfca2711e8031439fbab8bf9f70a20b8afc293faef8edd683ffbd6
Watermark: SYNTHETIC DEMONSTRATION DATA - NOT A REAL MUNICIPAL RECORD

# Records Response

Tracking number: REQ-0001
Requester: Fictional Audit Requester
Contact: No contact recorded.
Submitted via: Staff intake
Deadline: 2026-11-09
Deadline basis: Audit manually set deadline Rule: Synthetic three working days; received 2026-11-04; calculated as 3 business days from receipt; weekends are automatically skipped; city/state holidays must be checked by staff.
Assigned to: Fictional Records Officer
Status: release package built
Fee estimate: $0.00 waived: Synthetic audit waiver

## Request
Synthetic comprehensive UI audit request

## Request Timeline
  Id: records-timeline-5ba4e52e-76f7-4a6a-b54b-f860cf71e167
  Action: intake
  Actor: records staff
  Note: Staff created request REQ-0001 with deadline 2026-12-15.
  Created At Unix Seconds: 1793825763
  Id: records-timeline-7054f89b-0230-410e-8a8f-ed64f5edf157
  Action: deadline reviewed
  Actor: records staff
  Note: Response deadline set to 2026-12-16; basis: Audit manually set deadline.
  Created At Unix Seconds: 1793825764
  Id: records-timeline-1743fb64-10fc-4fb2-8109-d4e7f70b3cf9
  Action: deadline calculated
  Actor: records staff
  Note: Synthetic three working days: received 2026-11-04; due 2026-11-09. Audit manually set deadline Rule: Synthetic three working days; received 2026-11-04; calculated as 3 business days from receipt; weekends are automatically skipped; city/state holidays must be checked by staff.
  Created At Unix Seconds: 1793825764
  Id: records-timeline-6e17ca65-ba84-4a21-a11e-c70e689aa9c6
  Action: assigned
  Actor: records staff
  Note: Assigned to Fictional Records Officer.
  Created At Unix Seconds: 1793825765
  Id: records-timeline-c0d39a64-674e-4955-988f-01ae648a9857
  Action: clarification requested
  Actor: records staff
  Note: Synthetic date-range clarification
  Created At Unix Seconds: 1793825766
  Id: records-timeline-0b233978-50ae-4b0f-93b8-9d299227e8f5
  Action: search recorded
  Actor: records staff
  Note: Synthetic file cabinet checked Citation: Audit source one.
  Created At Unix Seconds: 1793825767
  Id: records-timeline-a614f27b-c575-4832-b4e4-7e69937cf896
  Action: search session recorded
  Actor: records staff
  Note: Synthetic audit source across Synthetic local folder; result Audit responsive record.
  Created At Unix Seconds: 1793825768
  Id: records-timeline-a87d8986-a66c-45d5-8797-ddca0c7ff44b
  Action: exemption review recorded
  Actor: records staff
  Note: Synthetic exemption review note
  Created At Unix Seconds: 1793825769
  Id: records-timeline-5507c32c-4fed-473c-996c-64a099bd28b7
  Action: exemption decision recorded
  Actor: records staff
  Note: release decision for Audit page 1: Synthetic staff finding under Synthetic policy basis.
  Created At Unix Seconds: 1793825770
  Id: records-timeline-d54350ba-2305-4ffe-b227-12a5c270318c
  Action: fee estimate saved
  Actor: records staff
  Note: 12.50
  Created At Unix Seconds: 1793825771
  Id: records-timeline-9a9a00e0-f041-4d6f-9058-3268769ab8d0
  Action: fee line added
  Actor: records staff
  Note: Synthetic copying: $2.50 under Fictional fee schedule
  Created At Unix Seconds: 1793825772
  Id: records-timeline-349edb6b-b08e-4c34-aa63-c402c5ae6f8f
  Action: fee waived
  Actor: records staff
  Note: Synthetic audit waiver
  Created At Unix Seconds: 1793825773
  Id: records-timeline-a2a1b2f5-de7e-4912-b04e-6435e5cde28c
  Action: message sent
  Actor: records staff
  Note: Synthetic requester-visible staff message
  Created At Unix Seconds: 1793825774
  Id: records-timeline-97acff8c-c59d-442d-8bd2-6d9615e94385
  Action: document attached
  Actor: records staff
  Note: Attached Synthetic original from fixture-source.txt; sha256 31e389467c99f5508e53974daa52c9f36b53045e6b4d3ef7ef5be1be95e9318a.
  Created At Unix Seconds: 1793825775
  Id: records-timeline-3b52c521-418b-4715-9341-cf290f976475
  Action: release copy attached
  Actor: records staff
  Note: release-ready copy attached for Synthetic original; sha256 31e389467c99f5508e53974daa52c9f36b53045e6b4d3ef7ef5be1be95e9318a. Synthetic reviewed release copy
  Created At Unix Seconds: 1793825775
  Id: records-timeline-72f60a33-3ee5-4575-8d72-9adfa09e9841
  Action: response drafted
  Actor: records staff
  Note: Draft response saved with citation Audit source one.
  Created At Unix Seconds: 1793825776
  Id: records-timeline-bde26af5-5049-448d-8c3e-1d27b22c4c96
  Action: response approved
  Actor: records staff
  Note: Synthetic human review approval
  Created At Unix Seconds: 1793825777
  Id: records-timeline-40aec71d-73ed-45a7-900d-48d37ec900df
  Action: release package built
  Actor: records staff
  Note: Release package manifest written to C:\Users\WDAGUtilityAccount\AppData\Local\CivicSuite\Data\exports\records\records-release-package-be8e49b7-8979-44eb-8181-99360309bdaa.md; sha256 d75b3f5cc38b1a820025a98f0b5e450e858003a340cf675436bfb851738b97b8.
  Created At Unix Seconds: 1793825778
  Id: records-timeline-8dc9b8b0-600c-4c70-9db9-316f703a6553
  Action: response package exported
  Actor: records staff
  Note: Approved response written to C:\Users\WDAGUtilityAccount\AppData\Local\CivicSuite\Data\exports\records\records-response-0fcfa992-7f58-4b48-967b-5edf81b7d726.md; sha256 3cd3249442046bd1ff2eff75e8589b3e989000aebd6b01db670ec1a0b7ce3d9d.
  Created At Unix Seconds: 1793825779
  Id: records-timeline-f4bce873-186d-4cfe-a0f6-b23dae4a8dc3
  Action: document attached
  Actor: records staff
  Note: Attached Notice archive 64660194-394f-4584-8584-106eb60d6e2a from notice-archive.zip; sha256 8b3e834499b2ff2c50b3d595548cee581919d6544c7fc835f10aee6a7580d7f8.
  Created At Unix Seconds: 1793825874
  Id: records-timeline-7b9a65a5-ddd5-4e64-a532-a7ce492c0863
  Action: document attached
  Actor: records staff
  Note: Attached Synthetic full UI permit intake from permitting-intake.txt; sha256 b72eba5a81b05fa14312f673c1a04d31b57881fe5767650ed702e379abff219d.
  Created At Unix Seconds: 1793826729
  Id: records-timeline-9a074934-da23-4fc8-b125-21f13dd55cb0
  Action: document attached
  Actor: records staff
  Note: Attached Synthetic full UI inspection from inspection-report.txt; sha256 f617b780aedd782f9dfbf42200dccf4915aff92f1f524089ab637fc1d4f45ab9.
  Created At Unix Seconds: 1793826754
  Id: records-timeline-2696707d-179e-4181-8cde-adf056291a94
  Action: document attached
  Actor: records staff
  Note: Attached Synthetic full UI planning analysis from planning.txt; sha256 c37439958974627e3383c58a1edfb7c0f661f107d915d8d0ec108a34bd765755.
  Created At Unix Seconds: 1793827609
  Id: records-timeline-0334a6e8-82e1-45cd-81d6-d4adc83d0f82
  Action: document attached
  Actor: records staff
  Note: Attached Zoning question c81083ce-48d7-471f-a942-e237f3955697 from zoning.txt; sha256 fadf540a3c42dc95be83f56c9d1e7f768af3767bdc5a3400a47f84911d7eee3e.
  Created At Unix Seconds: 1793827617
  Id: records-timeline-0dbbe6ac-d627-4dee-8c4c-2f1fd891a159
  Action: document attached
  Actor: records staff
  Note: Attached Synthetic Access full review export from access-70375a48-b06c-4707-aef2-0b798d6605e2.md; sha256 d5c460f2139f029691528f99e52e1862233366b8e6f8b79e96d859299d01852a.
  Created At Unix Seconds: 1793827623
  Id: records-timeline-f8c0c6f1-d728-42f7-bfdf-0fb3eac12540
  Action: document attached
  Actor: records staff
  Note: Attached Fictional audit council meeting — agenda from agenda.txt; sha256 78078a757d5d694a444a5a761e7e9c53d12a1ceedb0ec688d4fbc86184918dbc.
  Created At Unix Seconds: 1793827666
  Id: records-timeline-4977a157-1914-443c-a770-9d665f78018c
  Action: document attached
  Actor: records staff
  Note: Attached Fictional audit council meeting — Station recording from recording.ts; sha256 70a109b3dd801e7b3a0c5cb27c2b2ce37323ec4c4ce400d866c1b28b03bbaede.
  Created At Unix Seconds: 1793829475
  Id: records-timeline-587842e0-42a1-4f4e-849b-2f597cdcc2fd
  Action: document attached
  Actor: records staff
  Note: Attached 97.6b9c53f1 - Fictional audit ADU from ordinance.txt; sha256 faa15e4bab21431381c9f3ef60894a20cbda06150a78f7d195f21b1933ba42b8.
  Created At Unix Seconds: 1793829552
  Id: records-timeline-236257b2-3cc8-4890-8273-1ff7377f3e59
  Action: local AI draft generated
  Actor: local model
  Note: Draft generated with townlight-gemma4-12b-qat:q4_0; human approval still required.
  Created At Unix Seconds: 1793829756
  Id: records-timeline-c9b7dfb8-b82e-4377-934b-94e70bb07e72
  Action: response drafted
  Actor: records staff
  Note: Draft response saved with citation Synthetic audit source one.
  Created At Unix Seconds: 1793829764
  Id: records-timeline-4d6cc2f9-2e64-4cee-bdea-14d914947e7b
  Action: response approved
  Actor: records staff
  Note: Synthetic final human approval after cross-module attachments
  Created At Unix Seconds: 1793829768
  Id: records-timeline-032d3133-63cf-42b5-9cc3-ee3848903309
  Action: release package built
  Actor: records staff
  Note: Release package manifest written to C:\Users\WDAGUtilityAccount\AppData\Local\CivicSuite\Data\exports\records\records-release-package-6b35c600-ca53-4c8b-89a0-d13ad222bd27.md; sha256 a52875254eb9d0a329a268b70f012503e7984a05a73295c8260db70df72420d0.
  Created At Unix Seconds: 1793829776

## Request Messages
  Id: records-message-fbfd093d-46ca-4824-be81-fb5af58b8b07
  Author: Records staff
  Author Role: staff
  Body: Synthetic requester-visible staff message
  Visibility: requester thread
  Created At Unix Seconds: 1793825774

## Request Documents
  Id: records-document-7baeea28-06b3-406f-9b29-0ff3db10a007
  Attachment Id: 7baeea28-06b3-406f-9b29-0ff3db10a007
  Title: Synthetic original
  Original Path: C:\TownlightCandidate\fixture-source.txt
  Stored Path: C:\Users\WDAGUtilityAccount\AppData\Local\CivicSuite\Data\files\records\staged\f73b5b7c-cac0-4b2c-b6aa-b99a862a7792.txt
  Citation: Audit original
  Sha256: 31e389467c99f5508e53974daa52c9f36b53045e6b4d3ef7ef5be1be95e9318a
  Size Bytes: 71
  Status: release-ready copy attached
  Added By: records staff
  Created At Unix Seconds: 1793825775
  Release Original Path: C:\TownlightCandidate\fixture-source.txt
  Release Stored Path: C:\Users\WDAGUtilityAccount\AppData\Local\CivicSuite\Data\files\records\staged\e75f4883-b357-4467-bfa8-beb6fbf36164.txt
  Release File Name: fixture-source.txt
  Release Sha256: 31e389467c99f5508e53974daa52c9f36b53045e6b4d3ef7ef5be1be95e9318a
  Release Size Bytes: 71
  Release Status: release-ready copy
  Release Note: Synthetic reviewed release copy
  Release Added By: Fictional reviewer
  Release Added At Unix Seconds: 1793825775
  Id: records-document-818314a0-1a3d-455d-9be4-92163eb30527
  Attachment Id: 818314a0-1a3d-455d-9be4-92163eb30527
  Title: Notice archive 64660194-394f-4584-8584-106eb60d6e2a
  Original Path: townlight-notice:archive:edf44dba-2521-445b-9b0c-f395537decc2
  Stored Path: C:\Users\WDAGUtilityAccount\AppData\Local\CivicSuite\Data\files\records\notice\8932735d-e223-5497-8e7f-704ab0e98f09\notice-archive.zip
  Citation: Townlight Notice archive edf44dba-2521-445b-9b0c-f395537decc2; SHA256 8b3e834499b2ff2c50b3d595548cee581919d6544c7fc835f10aee6a7580d7f8
  Sha256: 8b3e834499b2ff2c50b3d595548cee581919d6544c7fc835f10aee6a7580d7f8
  Size Bytes: 2161
  Status: attached for response review
  Added By: records staff
  Created At Unix Seconds: 1793825874
  Release Original Path: 
  Release Stored Path: 
  Release File Name: 
  Release Sha256: 
  Release Size Bytes: 0
  Release Status: 
  Release Note: 
  Release Added By: 
  Release Added At Unix Seconds: None
  Id: records-document-04942d14-ac01-4fd6-bd99-8da11c3140ef
  Attachment Id: 04942d14-ac01-4fd6-bd99-8da11c3140ef
  Title: Synthetic full UI permit intake
  Original Path: permitting:0d80be50-9995-5e3d-b1eb-396c73e67937
  Stored Path: C:\Users\WDAGUtilityAccount\AppData\Local\CivicSuite\Data\files\records\permitting\d25c25e0-a71f-5579-b846-1bfc916082dd\permitting-intake.txt
  Citation: Townlight Permitting intake abe2ee4f-e293-43b8-bcde-eab98984e54b, revision 3881ace8-44ef-5de4-a3e7-c04e2f034705
  Sha256: b72eba5a81b05fa14312f673c1a04d31b57881fe5767650ed702e379abff219d
  Size Bytes: 5470
  Status: attached for response review
  Added By: records staff
  Created At Unix Seconds: 1793826728
  Release Original Path: 
  Release Stored Path: 
  Release File Name: 
  Release Sha256: 
  Release Size Bytes: 0
  Release Status: 
  Release Note: 
  Release Added By: 
  Release Added At Unix Seconds: None
  Id: records-document-7b3e94ae-00aa-440d-85d9-94e6d6171e44
  Attachment Id: 7b3e94ae-00aa-440d-85d9-94e6d6171e44
  Title: Synthetic full UI inspection
  Original Path: inspections:b48adb5b-f177-5b9d-a42e-f1f071acd42d
  Stored Path: C:\Users\WDAGUtilityAccount\AppData\Local\CivicSuite\Data\files\records\inspections\2f75e6c8-ae78-5348-bf6d-042a816abab7\inspection-report.txt
  Citation: Townlight Inspections report e8b04f72-37d5-4081-86fe-5991b69a51f1, revision 64e4818e-9177-51e8-8bdc-8e7c3890af49
  Sha256: f617b780aedd782f9dfbf42200dccf4915aff92f1f524089ab637fc1d4f45ab9
  Size Bytes: 3763
  Status: attached for response review
  Added By: records staff
  Created At Unix Seconds: 1793826754
  Release Original Path: 
  Release Stored Path: 
  Release File Name: 
  Release Sha256: 
  Release Size Bytes: 0
  Release Status: 
  Release Note: 
  Release Added By: 
  Release Added At Unix Seconds: None
  Id: records-document-94a1b7e3-c407-4cd9-9350-9bfbce8bea80
  Attachment Id: 94a1b7e3-c407-4cd9-9350-9bfbce8bea80
  Title: Synthetic full UI planning analysis
  Original Path: townlight:planning:snapshot:f06948e6-b52c-5f4e-8501-900543b42ab8
  Stored Path: C:\Users\WDAGUtilityAccount\AppData\Local\CivicSuite\Data\files\records\planning\04598b44-6d9c-542e-88d7-3c2713bc0795\planning.txt
  Citation: Planning review snapshot f06948e6-b52c-5f4e-8501-900543b42ab8; sha256=c37439958974627e3383c58a1edfb7c0f661f107d915d8d0ec108a34bd765755
  Sha256: c37439958974627e3383c58a1edfb7c0f661f107d915d8d0ec108a34bd765755
  Size Bytes: 3870
  Status: attached for response review
  Added By: records staff
  Created At Unix Seconds: 1793827608
  Release Original Path: 
  Release Stored Path: 
  Release File Name: 
  Release Sha256: 
  Release Size Bytes: 0
  Release Status: 
  Release Note: 
  Release Added By: 
  Release Added At Unix Seconds: None
  Id: records-document-91d34d7f-1975-4fc0-a52b-721ae753780f
  Attachment Id: 91d34d7f-1975-4fc0-a52b-721ae753780f
  Title: Zoning question c81083ce-48d7-471f-a942-e237f3955697
  Original Path: townlight:zoning:snapshot:4075ee98-801c-4ea4-8938-426944bf4eea
  Stored Path: C:\Users\WDAGUtilityAccount\AppData\Local\CivicSuite\Data\files\records\zoning\37772be0-ff7b-56c6-9743-46d21a6615bd\zoning.txt
  Citation: Source snapshot townlight:zoning:snapshot:4075ee98-801c-4ea4-8938-426944bf4eea
  Sha256: fadf540a3c42dc95be83f56c9d1e7f768af3767bdc5a3400a47f84911d7eee3e
  Size Bytes: 1112
  Status: attached for response review
  Added By: records staff
  Created At Unix Seconds: 1793827617
  Release Original Path: 
  Release Stored Path: 
  Release File Name: 
  Release Sha256: 
  Release Size Bytes: 0
  Release Status: 
  Release Note: 
  Release Added By: 
  Release Added At Unix Seconds: None
  Id: records-document-2fc98386-f412-476c-a293-3abdbc607b85
  Attachment Id: 2fc98386-f412-476c-a293-3abdbc607b85
  Title: Synthetic Access full review export
  Original Path: C:\Users\WDAGUtilityAccount\AppData\Local\CivicSuite\Data\exports\access\access-70375a48-b06c-4707-aef2-0b798d6605e2.md
  Stored Path: C:\Users\WDAGUtilityAccount\AppData\Local\CivicSuite\Data\files\records\staged\fe18c52c-1d2b-4dce-9144-fc53dc47a84a.md
  Citation: Audit Access review
  Sha256: d5c460f2139f029691528f99e52e1862233366b8e6f8b79e96d859299d01852a
  Size Bytes: 1389
  Status: attached for response review
  Added By: records staff
  Created At Unix Seconds: 1793827623
  Release Original Path: 
  Release Stored Path: 
  Release File Name: 
  Release Sha256: 
  Release Size Bytes: 0
  Release Status: 
  Release Note: 
  Release Added By: 
  Release Added At Unix Seconds: None
  Id: records-document-85bb2251-a977-4a58-91e1-8fc31d3aec18
  Attachment Id: 85bb2251-a977-4a58-91e1-8fc31d3aec18
  Title: Fictional audit council meeting — agenda
  Original Path: townlight:meetings:archive:696bfc84-2e9d-4922-888b-21faf81c7fb5:agenda
  Stored Path: C:\Users\WDAGUtilityAccount\AppData\Local\CivicSuite\Data\files\records\meetings\47bf10d1-51e7-54d6-9faa-0b49b729819e\agenda.txt
  Citation: townlight:meetings:archive:696bfc84-2e9d-4922-888b-21faf81c7fb5:agenda; sha256=78078a757d5d694a444a5a761e7e9c53d12a1ceedb0ec688d4fbc86184918dbc
  Sha256: 78078a757d5d694a444a5a761e7e9c53d12a1ceedb0ec688d4fbc86184918dbc
  Size Bytes: 25
  Status: attached for response review
  Added By: records staff
  Created At Unix Seconds: 1793827666
  Release Original Path: 
  Release Stored Path: 
  Release File Name: 
  Release Sha256: 
  Release Size Bytes: 0
  Release Status: 
  Release Note: 
  Release Added By: 
  Release Added At Unix Seconds: None
  Id: records-document-3cf1b3a9-4de7-4df2-941e-e5838d8dc8ca
  Attachment Id: 3cf1b3a9-4de7-4df2-941e-e5838d8dc8ca
  Title: Fictional audit council meeting — Station recording
  Original Path: townlight:station:recording:c012a756-a63c-4530-9e20-8e18ab30b29a
  Stored Path: C:\Users\WDAGUtilityAccount\AppData\Local\CivicSuite\Data\files\records\station\913aa9b1-4b76-5132-9aac-8314f778201f\recording.ts
  Citation: townlight:station:recording:c012a756-a63c-4530-9e20-8e18ab30b29a; meeting=d316be11-a751-43f1-8c85-53bafe51411f; sha256=70a109b3dd801e7b3a0c5cb27c2b2ce37323ec4c4ce400d866c1b28b03bbaede
  Sha256: 70a109b3dd801e7b3a0c5cb27c2b2ce37323ec4c4ce400d866c1b28b03bbaede
  Size Bytes: 458532
  Status: attached for response review
  Added By: records staff
  Created At Unix Seconds: 1793829474
  Release Original Path: 
  Release Stored Path: 
  Release File Name: 
  Release Sha256: 
  Release Size Bytes: 0
  Release Status: 
  Release Note: 
  Release Added By: 
  Release Added At Unix Seconds: None
  Id: records-document-f22fe7d2-120d-4535-84fa-fd1773e686be
  Attachment Id: f22fe7d2-120d-4535-84fa-fd1773e686be
  Title: 97.6b9c53f1 - Fictional audit ADU
  Original Path: townlight:code:export:ee42289bb98e5883e0879ee75da42093fbf8f144684cc4993175d4ae2192c363
  Stored Path: C:\Users\WDAGUtilityAccount\AppData\Local\CivicSuite\Data\files\records\code\5c7e535f-ff8f-522f-afe7-95133b2b7b06\ordinance.txt
  Citation: Title 97 (Fictional audit), Chapter 97.1 (Fictional audit), Section 97.6b9c53f1 (Fictional audit ADU), version Fictional adopted, effective 2026-11-04; source=townlight:code:export:ee42289bb98e5883e0879ee75da42093fbf8f144684cc4993175d4ae2192c363; sha256=faa15e4bab21431381c9f3ef60894a20cbda06150a78f7d195f21b1933ba42b8
  Sha256: faa15e4bab21431381c9f3ef60894a20cbda06150a78f7d195f21b1933ba42b8
  Size Bytes: 2101
  Status: attached for response review
  Added By: records staff
  Created At Unix Seconds: 1793829552
  Release Original Path: 
  Release Stored Path: 
  Release File Name: 
  Release Sha256: 
  Release Size Bytes: 0
  Release Status: 
  Release Note: 
  Release Added By: 
  Release Added At Unix Seconds: None

## Release Packages
  Id: records-release-package-be8e49b7-8979-44eb-8181-99360309bdaa
  Export Path: C:\Users\WDAGUtilityAccount\AppData\Local\CivicSuite\Data\exports\records\records-release-package-be8e49b7-8979-44eb-8181-99360309bdaa.md
  Package Hash: d75b3f5cc38b1a820025a98f0b5e450e858003a340cf675436bfb851738b97b8
  Document Count: 1
  Release Artifact Count: 1
  Search Session Count: 1
  Release Count: 1
  Redacted Count: 0
  Exempt Count: 0
  Created At Unix Seconds: 1793825778
  Id: records-release-package-6b35c600-ca53-4c8b-89a0-d13ad222bd27
  Export Path: C:\Users\WDAGUtilityAccount\AppData\Local\CivicSuite\Data\exports\records\records-release-package-6b35c600-ca53-4c8b-89a0-d13ad222bd27.md
  Package Hash: a52875254eb9d0a329a268b70f012503e7984a05a73295c8260db70df72420d0
  Document Count: 10
  Release Artifact Count: 1
  Search Session Count: 1
  Release Count: 1
  Redacted Count: 0
  Exempt Count: 0
  Created At Unix Seconds: 1793829776

## Fee Review
  Id: records-fee-line-aee208ca-29d3-4b9d-9bff-eaa616c63400
  Description: Synthetic copying
  Schedule Basis: Fictional fee schedule
  Amount Cents: 250
  Created At Unix Seconds: 1793825772

## Clarification Notes
- Synthetic date-range clarification

## Search Notes
- Synthetic file cabinet checked

## Search Sessions
  Id: records-search-session-327737c8-0460-44cd-a3d6-405f00ebb876
  Query: Synthetic audit source
  Locations: Synthetic local folder
  Reviewer: Fictional Records Officer
  Results: [{'id': 'records-search-result-4d1948de-6d27-476f-b46c-1048f2b53f4d', 'title': 'Audit responsive record', 'citation': 'Audit citation', 'summary': 'Synthetic responsive result', 'status': 'responsive'}]
  Created At Unix Seconds: 1793825768

## Exemption Review Notes
- Synthetic exemption review note

## Exemption Decisions
  Id: records-exemption-decision-f9387485-b8a1-42fb-b27c-f6162c8bf5f6
  Source: Audit page 1
  Kind: Synthetic category
  Finding: Synthetic staff finding
  Decision: release
  Basis: Synthetic policy basis
  Reviewer: Fictional reviewer
  Created At Unix Seconds: 1793825770

## Citations
- Audit source one
- Audit citation
- Synthetic policy basis
- Audit original
- Audit source one
- Townlight Notice archive edf44dba-2521-445b-9b0c-f395537decc2; SHA256 8b3e834499b2ff2c50b3d595548cee581919d6544c7fc835f10aee6a7580d7f8
- Townlight Permitting intake abe2ee4f-e293-43b8-bcde-eab98984e54b, revision 3881ace8-44ef-5de4-a3e7-c04e2f034705
- Townlight Inspections report e8b04f72-37d5-4081-86fe-5991b69a51f1, revision 64e4818e-9177-51e8-8bdc-8e7c3890af49
- Planning review snapshot f06948e6-b52c-5f4e-8501-900543b42ab8; sha256=c37439958974627e3383c58a1edfb7c0f661f107d915d8d0ec108a34bd765755
- Source snapshot townlight:zoning:snapshot:4075ee98-801c-4ea4-8938-426944bf4eea
- Audit Access review
- townlight:meetings:archive:696bfc84-2e9d-4922-888b-21faf81c7fb5:agenda; sha256=78078a757d5d694a444a5a761e7e9c53d12a1ceedb0ec688d4fbc86184918dbc
- townlight:station:recording:c012a756-a63c-4530-9e20-8e18ab30b29a; meeting=d316be11-a751-43f1-8c85-53bafe51411f; sha256=70a109b3dd801e7b3a0c5cb27c2b2ce37323ec4c4ce400d866c1b28b03bbaede
- Title 97 (Fictional audit), Chapter 97.1 (Fictional audit), Section 97.6b9c53f1 (Fictional audit ADU), version Fictional adopted, effective 2026-11-04; source=townlight:code:export:ee42289bb98e5883e0879ee75da42093fbf8f144684cc4993175d4ae2192c363; sha256=faa15e4bab21431381c9f3ef60894a20cbda06150a78f7d195f21b1933ba42b8
- Synthetic audit source one

## Approval Notes
- Synthetic human review approval
- Synthetic final human approval after cross-module attachments

Fee waiver: Synthetic audit waiver

## Approved Response
Synthetic released response: the fictional workflow audit is complete. No private staff evidence is included in this letter.
