# Townlight Access record

```json
{
  "advice": {
    "ai_analysis": "REMEDIATION ANALYSIS: Synthetic AI audit review\n\nPriority Finding: missing-alt-text (High)\nAction: Provide descriptive alternative text for all images and visual elements within the document. \nReasoning: This is a high-priority accessibility barrier. Without alt text, users relying on screen readers cannot access any non-textual information, making the document partially inaccessible.\n\nHuman Reviewer Notes:\n1. Content Context: Ensure that the \"fictional library\" example serves its intended purpose and isn't confusing to residents looking for actual city services.\n2. Clarity: Verify that the instruction to \"Call the city for an accessible copy\" includes a direct phone number or link, as this creates a barrier if the contact info is missing.\n3. Structure: Check that headings are used logically (e.g., H1 for title, H2 for sections) to allow easy navigation via assistive technology.\n\nAdvisory only; a qualified human reviewer makes the final call.",
    "ai_analysis_model": "townlight-gemma4-12b-qat:q4_0",
    "ai_outcome": "generated",
    "legacy_id": null,
    "review_id": "07bf3506-5e9c-447c-865c-85814c153b87"
  },
  "audit_events": [
    {
      "action": "review.create",
      "actor": "b538845e-25db-5b47-8c3e-36dbe94dd41f",
      "created_at": "2026-11-04T21:14:29.342486+00:00",
      "event_id": "cbdbee6d-a002-4bf2-9c37-2a72faf3d2df",
      "subject_id": "07bf3506-5e9c-447c-865c-85814c153b87"
    }
  ],
  "disclaimer": "Accessibility review is advisory support only; it does not replace legal review, a certified accessibility audit, or an ADA coordinator's decision.",
  "exported_at": "2026-11-04T22:07:41.112378+00:00",
  "exported_by": "b538845e-25db-5b47-8c3e-36dbe94dd41f",
  "kind": "review",
  "review": {
    "body": "The fictional library opens at nine on Monday. Call the city for an accessible copy.",
    "created_at": "2026-11-04T21:14:29.338026+00:00",
    "disclaimer": "Accessibility review is advisory support only; it does not replace legal review, a certified accessibility audit, or an ADA coordinator's decision.",
    "findings": [
      {
        "code": "missing-alt-text",
        "fix": "Add concise alt text that explains the purpose of the visual, or mark decorative images as decorative.",
        "message": "At least one image or visual element is missing alternative text.",
        "severity": "high",
        "wcag_reference": "WCAG 1.1.1 Non-text Content"
      }
    ],
    "has_alt_text": false,
    "language": "en",
    "review_id": "07bf3506-5e9c-447c-865c-85814c153b87",
    "status": "needs-fixes",
    "title": "Synthetic AI audit review"
  },
  "schema_version": 1
}
```
