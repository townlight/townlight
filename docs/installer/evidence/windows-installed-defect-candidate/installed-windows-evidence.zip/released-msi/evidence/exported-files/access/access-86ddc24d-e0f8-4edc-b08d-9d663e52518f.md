# Townlight Access record

```json
{
  "audit_events": [
    {
      "action": "multilingual.variant",
      "actor": "b538845e-25db-5b47-8c3e-36dbe94dd41f",
      "created_at": "2026-11-04T21:14:38.892940+00:00",
      "event_id": "6e1d345a-f6d4-400d-b402-3985f9eb190a",
      "subject_id": "d6518b7e-bfcc-45c7-8591-3eefd0eb3c92"
    }
  ],
  "disclaimer": "Accessibility review is advisory support only; it does not replace legal review, a certified accessibility audit, or an ADA coordinator's decision.",
  "draft": {
    "action": "language-variant",
    "actor_id": "b538845e-25db-5b47-8c3e-36dbe94dd41f",
    "created_at": "2026-11-04T21:14:38.891882+00:00",
    "draft_id": "d6518b7e-bfcc-45c7-8591-3eefd0eb3c92",
    "language": "es",
    "model": "townlight-gemma4-12b-qat:q4_0",
    "outcome": "generated",
    "result_text": "La biblioteca ficticia abre a las nueve el lunes.",
    "review_status": "qualified-human-review-required",
    "source_text": "The fictional library opens at nine on Monday."
  },
  "exported_at": "2026-11-04T21:14:47.839986+00:00",
  "exported_by": "b538845e-25db-5b47-8c3e-36dbe94dd41f",
  "kind": "draft",
  "schema_version": 1
}
```
