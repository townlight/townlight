﻿param(
    [Parameter(Mandatory)][ValidateSet('directory','file')][string]$Kind,
    [Parameter(Mandatory)][string]$Path,
    [Parameter(Mandatory)][ValidatePattern('^[a-z0-9-]+$')][string]$Id
)
$ErrorActionPreference = 'Stop'
if ($env:USERNAME -ne 'WDAGUtilityAccount') { throw 'Disposable guest only' }
$profile = [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'CivicSuite'))
$resolved = (Resolve-Path -LiteralPath $Path).ProviderPath
if (!$resolved.StartsWith($profile + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw 'Handle target must stay in disposable candidate profile' }
$out = 'C:\TownlightEvidence'
$release = "C:\TownlightEvidence\release-$Id.txt"
if (Test-Path -LiteralPath $release) { throw 'Handle release marker already exists' }
$handle = $null
try {
    if ($Kind -eq 'directory') {
        if (!(Test-Path -LiteralPath $resolved -PathType Container)) { throw 'Expected directory' }
        Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;
public static class RecoveryDirectoryHandle {
    [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
    public static extern SafeFileHandle CreateFile(string name, uint access, uint share,
        IntPtr security, uint creation, uint flags, IntPtr template);
}
'@
        $handle = [RecoveryDirectoryHandle]::CreateFile($resolved, [uint32]2147483648, 3, [IntPtr]::Zero, 3, 0x02000000, [IntPtr]::Zero)
        if ($handle.IsInvalid) { throw "Directory handle failed: $([Runtime.InteropServices.Marshal]::GetLastWin32Error())" }
    } else {
        $handle = [IO.File]::Open($resolved, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::Read)
    }
    [ordered]@{pid=$PID;started=(Get-Process -Id $PID).StartTime.ToUniversalTime().ToString('o');kind=$Kind;path=$resolved;held=$true;release_marker=$release} |
        ConvertTo-Json | Set-Content -LiteralPath "$out\$Id-held.json" -Encoding utf8
    $deadline = (Get-Date).AddMinutes(20)
    while (!(Test-Path -LiteralPath $release) -and (Get-Date) -lt $deadline) { Start-Sleep -Seconds 1 }
} catch {
    $_ | Out-String | Set-Content -LiteralPath "$out\$Id-handle-failure.txt" -Encoding utf8
    throw
} finally {
    if ($null -ne $handle) { $handle.Dispose() }
    [ordered]@{pid=$PID;closed=[datetime]::UtcNow.ToString('o');kind=$Kind;path=$resolved;held=$false} |
        ConvertTo-Json | Set-Content -LiteralPath "$out\$Id-closed.json" -Encoding utf8
}
