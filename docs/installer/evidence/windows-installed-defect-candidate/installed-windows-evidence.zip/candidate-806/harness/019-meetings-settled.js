(async()=>{
 const a=window.audit, f=a.fixture??={};const rows=[];
 await a.nav('meetings'); f.meetingsInventory=a.inventory();
 async function run(action,values={},attribute='data-meetings-action',check=r=>r&&typeof r==='object'){
   let result;const row=await a.test('meetings/'+action,async()=>{await a.form('form['+attribute+'="'+action+'"]',values);const text=document.querySelector('[data-meetings-result]').textContent;try{result=JSON.parse(text);}catch{throw Error(text);}},r=>!r.calls.some(c=>c.error)&&check(result));
   rows.push(row);return result;
 }
 f.meeting=await run('meeting',{title:'Fictional audit council meeting',scheduled_start:'2026-12-10T18:00:00-07:00',location:'Fictional chamber',meeting_type:'regular'},'data-meetings-create',r=>!!r.id);
 f.agenda=await run('agenda-item',{title:'Fictional audit agenda',department_name:'Fictional clerk'},'data-meetings-create',r=>!!r.id);
 if(!f.meeting?.id||!f.agenda?.id)return {rows,fixture:f};
 const m=f.meeting.id,g=f.agenda.id;
 for(const to_status of ['SUBMITTED','DEPT_APPROVED','LEGAL_REVIEWED','CLERK_ACCEPTED'])await run('recordAgendaReview',{id:g,to_status});
 await run('assignAgendaMeeting',{id:g,meeting_id:m});
 await run('recordAgendaReview',{id:g,to_status:'ON_AGENDA'});
 f.packet=await run('capturePacket',{id:m,agenda_item_ids:g,source_paths:'C:\\TownlightCandidate\\fixture-source.txt'},undefined,r=>!!r.packet_id);
 if(f.packet?.packet_id)f.packetDelivery=await run('deliverPacket',{id:f.packet.packet_id});
 await run('openExports',{},undefined,r=>!!r);
 f.noticeCheck=await run('checkNotice',{id:m,notice_type:'regular',posted_at:'2026-12-08T09:00:00-07:00',minimum_notice_hours:'24',statutory_basis:'Synthetic staff fixture, no legal claim',approved_by:'Fictional reviewer'});
 const nc=f.noticeCheck?.id||f.noticeCheck?.notice_id||f.noticeCheck?.check_id;
 if(nc){f.noticeTemplate=await run('getNoticeTemplate',{id:nc});f.noticeDocument=await run('deliverNotice',{id:nc,text:'Synthetic meeting notice. Audit fixture only.'});await run('recordNoticeProof',{id:nc,location:'Synthetic local posting board',note:'No actual public posting',document_delivery_id:f.noticeDocument?.delivery_id||''});}
 await run('recordMeetingStage',{id:m,to_status:'NOTICED',statutory_basis:'Synthetic fixture'});
 await run('recordMeetingStage',{id:m,to_status:'PACKET_POSTED'});
 await run('recordMeetingStage',{id:m,to_status:'IN_PROGRESS'});
 f.motion=await run('captureMotion',{id:m,text:'Synthetic original motion',seconded_by:'Fictional member B'},undefined,r=>!!r.id);
 if(f.motion?.id){f.vote=await run('captureVote',{id:f.motion.id,voter_name:'Fictional member A',vote:'yes'},undefined,r=>!!r.id);f.motionCorrection=await run('correctMotion',{id:f.motion.id,text:'Synthetic corrected motion',reason:'Audit append-only correction'});await run('captureActionItem',{id:m,description:'Synthetic follow-up',assigned_to:'Fictional clerk',source_motion_id:f.motion.id});}
 if(f.vote?.id)f.voteCorrection=await run('correctVote',{id:f.vote.id,vote:'abstain',reason:'Audit append-only correction'});
 f.transcript=await run('captureTranscript',{id:m,source_label:'Synthetic source',transcript_text:'Synthetic original transcript.'});
 const transcriptId=f.transcript?.id||f.transcript?.transcript_id;
 if(transcriptId)await run('captureTranscript',{id:m,source_label:'Synthetic corrected source',transcript_text:'Synthetic corrected transcript.',correction_of_id:transcriptId});
 f.minutes=await run('createMinutes',{id:m,source_id:'audit-motion',label:'Synthetic source',source_text:'Synthetic corrected motion',text:'Synthetic corrected motion'},undefined,r=>!!r.id);
 if(f.minutes?.id)for(const action of ['post','adopt','sign'])await run('recordMinutesDecision',{id:f.minutes.id,action,note:'Synthetic '+action+' attestation'});
 f.archive=await run('archiveMeeting',{id:m,visibility:'public',packet_id:f.packet?.packet_id||'',minutes_id:f.minutes?.id||'',plain_language_summary:'Fictional audit public meeting summary'});
 await run('recordMeetingStage',{id:m,to_status:'ARCHIVED'});
 f.meetingRead=await run('',{kind:'meeting',id:m},'data-meetings-read',r=>r.id===m&&r.title===f.meeting.title);
 f.agendaRead=await run('',{kind:'agenda-item',id:g},'data-meetings-read',r=>r.id===g&&r.meeting_id===m);
 f.proceedings=await run('',{kind:'proceedings',id:m},'data-meetings-read',r=>r.meeting?.id===m&&r.motions?.some(x=>x.id===f.motion?.id)&&r.votes?.some(x=>x.id===f.vote?.id)&&r.archive_records?.some(x=>x.id===f.archive?.id));
 await run('codeConnections',{},undefined,r=>Array.isArray(r));
 return {rows,fixture:f,inventory:a.inventory()};
})()
