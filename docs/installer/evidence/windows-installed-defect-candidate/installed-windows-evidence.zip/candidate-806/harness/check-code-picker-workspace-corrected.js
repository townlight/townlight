(async()=>{
 const a=window.audit,f=a.fixture,rows=[],state=()=>a.native('suite_domain_request',{request:{operation:'state'}});
 const priorAttempt=a.records.filter(r=>r.id.startsWith('D5/')||r.id==='code/workspace');
 await a.nav('records');
 const selected=[...document.querySelectorAll('[data-select-work-record="recordsRequest"]')].find(e=>e.dataset.recordId===f.records.id);if(selected)await a.click(selected);
 const before=(await state()).records_requests.find(r=>r.request_id===f.records.request_id).documents.length;
 rows.push(await a.test('D5/full-profile-code-picker-corrected-selector',async()=>{
  await a.form('[data-code-sources] form',{query:f.codeIds.number});
  await a.until(()=>!!document.querySelector('[data-code-sources] [data-code-results] button'));
  await a.click('[data-code-sources] [data-code-results] button');
  await a.until(async()=>(await state()).records_requests.find(r=>r.request_id===f.records.request_id).documents.length>before);
 },async()=>(await state()).records_requests.find(r=>r.request_id===f.records.request_id).documents.length===before+1));
 const request=(await state()).records_requests.find(r=>r.request_id===f.records.request_id);
 await a.nav('code');
 rows.push(await a.test('code/workspace-rendered-and-persisted-readback',async()=>{await a.form('[data-code-action="workspace"]',{});},()=>{
  const output=document.querySelector('[data-code-output]').textContent;
  const jsonStart=output.indexOf('\n{\n');if(jsonStart<0)return false;
  const data=JSON.parse(output.slice(jsonStart));return data.sections.some(s=>s.section_id===f.codeIds.section&&s.current_version.version_id===f.codeIds.adopted)&&output.includes('Fictional audit ADU');
 }));
 return {rows,request,priorAttempt,corrections:['Code picker uses data-code-results; original harness wrongly used Meetings data-source-results.','Workspace presents human-readable field text followed by JSON; parse the actual JSON block.']};
})()
