(async()=>{
 const a=window.audit,f=a.fixture,rows=[];await a.nav('inspections');const st=()=>document.querySelector('[data-inspections-status]')?.textContent||'';const run=async(id,fn,check)=>rows.push(await a.test('inspections/'+id,fn,check||(()=>!/not confirmed/i.test(st()))));
 await run('navigate',async()=>{},()=>!!document.querySelector('[data-inspections]'));
 await run('new-case',()=>a.click('[data-inspections-action="new"]'),()=>!!document.querySelector('[data-inspections-case]'));
 const vals={title:'Synthetic full UI inspection',property_reference:'PRIVATE-INSPECTION-PROPERTY-731',inspection_reference:'SYN-AUDIT-731',dataset_kind:'fictional',inspector_notes:'PRIVATE-INSPECTOR-NOTES-731',photo_observations:'Synthetic fence observation',voice_notes:'PRIVATE-VOICE-TRANSCRIPT-731',assigned_to:'Audit inspector',staff_notes:'PRIVATE-INSPECTION-STAFF-731',review_notes:'Synthetic reviewed original',public_summary:'Synthetic public inspection summary'};
 for(const[k,v]of Object.entries(vals))a.fill('[data-inspections-case] [name="'+k+'"]',v);
 await run('retain-original-bytes',async()=>{a.file('[data-inspections-file]','audit-original.txt','Synthetic inspection original bytes, fixture 731.','text/plain');await a.wait();},()=>!!document.querySelector('[data-inspections-remove-evidence]'));
 await run('code-context-search',()=>a.form('[data-inspections-search]',{query:f.codeIds.number}),()=>!!document.querySelector('[data-inspections-select]'));
 await run('select-code-citation',()=>a.click('[data-inspections-select="0"]'),()=>!!document.querySelector('[data-inspections-remove]'));
 await run('analyse-originals',()=>a.click('[data-inspections-action="analyse"]'),()=>!!document.querySelector('[data-inspections-analysis] pre'));f.inspectionMedia=document.querySelector('[data-inspections-analysis]')?.textContent;
 await run('draft-notice',()=>a.click('[data-inspections-action="notice"]'),()=>!!document.querySelector('[name="notice_draft"]').value);
 await run('save-draft',()=>a.click(document.querySelector('[data-inspections-case] button[type="submit"]')),()=>st().includes('Inspection draft saved'));
 await run('explicit-inspector-review',()=>a.click('[data-inspections-action="review"]'),()=>st().includes('Inspector review recorded'));
 await run('history',()=>a.click('[data-inspections-action="history"]'),()=>document.querySelector('[data-inspections-history]').textContent.includes('PRIVATE-INSPECTOR-NOTES-731'));
 await run('report-readback',()=>a.click('[data-inspections-action="report"]'),()=>document.querySelector('[data-inspections-history]').textContent.includes('Synthetic'));
 await run('exact-property-repeat',()=>a.click('[data-inspections-action="repeat"]'),()=>document.querySelector('[data-inspections-repeat]').textContent.includes('Synthetic full UI inspection'));
 await run('staff-packet',()=>a.click('[data-inspections-action="staff-packet"]'),()=>document.querySelector('[data-inspections-packet]').textContent.includes('PRIVATE-VOICE-TRANSCRIPT-731'));
 await run('export-staff-packet',()=>a.click('[data-inspections-action="export"]'),()=>/Exact packet saved:.*SHA256/.test(st()));f.inspectionStaffExport=st();
 await run('records-copy-private-redaction',()=>a.click('[data-inspections-action="records-packet"]'),()=>{const t=document.querySelector('[data-inspections-packet]').textContent;return t.includes('Synthetic public inspection summary')&&!/PRIVATE-INSPECT|PRIVATE-VOICE|audit-original.txt/.test(t);});
 await run('export-records-copy',()=>a.click('[data-inspections-action="export"]'),()=>/Exact packet saved:.*SHA256/.test(st()));f.inspectionRecordsExport=st();
 await run('attach-records-copy',()=>a.form('[data-inspections-attach]',{request_id:f.records.request_id}),async()=>st().includes('Reviewed inspection copy attached')&&(await a.native('suite_domain_request',{request:{operation:'state'}})).records_requests.find(r=>r.request_id===f.records.request_id).documents.some(d=>/inspection/i.test(JSON.stringify(d))));
 await run('remove-original-from-new-revision',()=>a.click('[data-inspections-remove-evidence="0"]'),()=>!document.querySelector('[data-inspections-remove-evidence]'));
 await run('remove-code-citation',()=>a.click('[data-inspections-remove="0"]'),()=>!document.querySelector('[data-inspections-remove]'));
 await run('save-new-revision',()=>a.click(document.querySelector('[data-inspections-case] button[type="submit"]')),()=>st().includes('Inspection draft saved'));
 await a.click('[data-inspections-action="cases"]');await run('reopen-case',()=>a.click('[data-inspections-open="0"]'),()=>document.querySelector('[name="title"]').value===vals.title);
 await run('immutable-original-history',()=>a.click('[data-inspections-action="history"]'),()=>document.querySelector('[data-inspections-history]').textContent.includes('audit-original.txt'));
 f.inspectionsInventory=a.inventory();return {rows,fixture:f,inventory:f.inspectionsInventory};
})()
