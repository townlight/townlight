﻿$ErrorActionPreference='Stop'
if($env:USERNAME -ne 'WDAGUtilityAccount'){throw 'Disposable guest only'}
$out='C:\TownlightEvidence'
$fixture=Get-Content -LiteralPath "$out\recovery-fixture.json" -Raw|ConvertFrom-Json
function Invoke-RecoveryUi([string]$Name,[string]$Expression){
 $path=Join-Path $env:TEMP ($Name+'.js');if(Test-Path -LiteralPath "$out\$Name.json"){throw 'Recovery evidence exists'}
 [IO.File]::WriteAllText($path,$Expression)
 & C:\TownlightCandidate\invoke-installed-webview.ps1 -JavaScriptPath $path -TimeoutMinutes 12 | Set-Content -LiteralPath "$out\$Name.json" -Encoding utf8
 if(!$?){throw 'UI transport failed'}
 return (Get-Content -LiteralPath "$out\$Name.json" -Raw|ConvertFrom-Json)
}
function Start-RecoveryHandle([string]$Kind,[string]$Target,[string]$Id){
 $child=Start-Process powershell.exe -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File','C:\TownlightCandidate\hold-recovery-handle.ps1','-Kind',$Kind,'-Path',('"'+$Target+'"'),'-Id',$Id) -WindowStyle Hidden -PassThru
 $end=(Get-Date).AddSeconds(20)
 while(!(Test-Path -LiteralPath "$out\$Id-held.json") -and (Get-Date) -lt $end){if($child.HasExited){throw 'Handle process exited before ready'};Start-Sleep -Milliseconds 200}
 if(!(Test-Path -LiteralPath "$out\$Id-held.json")){throw 'Handle not ready'}
 return $child
}
function Release-RecoveryHandle([string]$Id,$Child){
 [IO.File]::WriteAllText("C:\TownlightEvidence\release-$Id.txt",'release')
 if(!$Child.WaitForExit(10000)){throw 'Owned handle child did not exit'}
 if(!(Test-Path -LiteralPath "$out\$Id-closed.json")){throw 'Handle closure receipt missing'}
}
# Input share is read-only in the guest: release markers use the evidence share.
$backup=Invoke-RecoveryUi 'recovery-backup-ui' '(async()=>{const a=window.audit;await a.ensureRuntime();await a.click("[data-surface=\"IT/Admin\"]");await a.nav("health");await a.click("[data-supervisor-action=\"backup\"]",{timeout:600000});return{result:[...document.querySelectorAll(".action-result")].map(e=>e.textContent),app:await a.native("get_app_state")};})()'
if(($backup.result -join ' ') -notmatch 'backup|Backup'){throw 'Backup control result missing'}
$backups=Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'Townlight Backups'
$latest=Get-ChildItem -LiteralPath $backups -Directory|Sort-Object LastWriteTimeUtc -Descending|Select-Object -First 1
if(!$latest -or !(Test-Path -LiteralPath (Join-Path $latest.FullName 'backup-manifest.json'))){throw 'Verified backup manifest missing'}
[IO.File]::WriteAllText($fixture.sentinel,'Synthetic CHANGED candidate sentinel.')
[IO.File]::WriteAllText($fixture.locked,'Synthetic CHANGED locked-last sentinel.')
[IO.File]::WriteAllText($fixture.model,'Synthetic CURRENT cache marker to preserve.')
$changed=(Get-FileHash -LiteralPath $fixture.sentinel).Hash;$currentCache=(Get-FileHash -LiteralPath $fixture.model).Hash
$open=Invoke-RecoveryUi 'recovery-open-exports-ui' '(async()=>{const a=window.audit;await a.ensureRuntime();await a.nav("access");await a.click("[data-work-action=\"open-exports-folder\"]");return{text:document.querySelector("main").innerText};})()'
$directory=Start-RecoveryHandle 'directory' $fixture.exports 'restore-dir'
try{
 $restored=Invoke-RecoveryUi 'recovery-open-directory-restore-ui' '(async()=>{const a=window.audit;await a.nav("health");await a.click("[data-supervisor-action=\"restore\"]",{timeout:600000});return{result:[...document.querySelectorAll(".action-result")].map(e=>e.textContent),app:await a.native("get_app_state")};})()'
 $restoredHash=(Get-FileHash -LiteralPath $fixture.sentinel).Hash
 $preservedCache=(Get-FileHash -LiteralPath $fixture.model).Hash
 $pass=$restoredHash -eq $fixture.original_sha256 -and $preservedCache -eq $currentCache
 [ordered]@{passed=$pass;backup=$latest.FullName;original=$fixture.original_sha256;changed=$changed;restored=$restoredHash;current_cache=$currentCache;preserved_cache=$preservedCache;directory_handle='restore-dir-held.json';method='Actual installed Restore with open Explorer exports folder and no-delete directory handle; independent file hashes'}|ConvertTo-Json|Set-Content -LiteralPath "$out\recovery-directory-verification.json" -Encoding utf8
 if(!$pass){throw 'Open-directory restore did not restore bytes/preserve current cache'}
}finally{Release-RecoveryHandle 'restore-dir' $directory}
$read=Invoke-RecoveryUi 'recovery-restored-links' '(async()=>{const a=window.audit;await a.ensureRuntime();const s=await a.native("suite_domain_request",{request:{operation:"state"}});const request=s.records_requests.find(r=>r.request_id===a.fixture.records.request_id);return{passed:!!request&&request.documents.length>=2,request};})()'
if(!$read.passed){throw 'Restored database links missing'}
[IO.File]::WriteAllText($fixture.sentinel,'Synthetic ROLLBACK current sentinel.')
[IO.File]::WriteAllText($fixture.locked,'Synthetic ROLLBACK current locked-last sentinel.')
$rollbackBefore=(Get-FileHash -LiteralPath $fixture.sentinel).Hash;$lockedBefore=(Get-FileHash -LiteralPath $fixture.locked).Hash
$file=Start-RecoveryHandle 'file' $fixture.locked 'restore-file'
try{
 $failed=Invoke-RecoveryUi 'recovery-locked-file-restore-ui' '(async()=>{const a=window.audit;await a.nav("health");await a.click("[data-supervisor-action=\"restore\"]",{timeout:600000});return{blocked:!!document.querySelector(".action-result.blocked"),result:[...document.querySelectorAll(".action-result")].map(e=>e.textContent)};})()'
 $rollbackAfter=(Get-FileHash -LiteralPath $fixture.sentinel).Hash;$lockedAfter=(Get-FileHash -LiteralPath $fixture.locked).Hash
 $pass=$failed.blocked -and $rollbackBefore -eq $rollbackAfter -and $lockedBefore -eq $lockedAfter -and ($failed.result -join ' ') -match 'rolled back|rollback|restored'
 [ordered]@{passed=$pass;explicit_failure=$failed;before=$rollbackBefore;after=$rollbackAfter;locked_before=$lockedBefore;locked_after=$lockedAfter;method='No-delete/no-write file lock forces real restore failure after earlier file moves; unchanged current bytes prove rollback'}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$out\recovery-rollback-verification.json" -Encoding utf8
 if(!$pass){throw 'Locked-file failure/rollback not verified'}
}finally{Release-RecoveryHandle 'restore-file' $file}
Invoke-RecoveryUi 'recovery-after-rollback-links' '(async()=>{const a=window.audit;await a.ensureRuntime();const s=await a.native("suite_domain_request",{request:{operation:"state"}});const request=s.records_requests.find(r=>r.request_id===a.fixture.records.request_id);return{passed:!!request&&request.documents.length>=2,request};})()' | Out-Null
