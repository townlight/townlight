$ErrorActionPreference='Stop'
if($env:USERNAME -ne 'WDAGUtilityAccount'){throw 'Disposable guest only'}
$out='C:\TownlightEvidence'
$installed=Get-Content -LiteralPath "$out\candidate-installed.json" -Raw|ConvertFrom-Json
$python=Join-Path $installed.payload 'python\python.exe'
& $python -I -B C:\TownlightCandidate\provision-station.py
if($LASTEXITCODE){throw 'Dedicated Station DB provision failed'}
$config=Get-Content -LiteralPath "$out\beta-station-database.json" -Raw|ConvertFrom-Json
foreach($item in $config.configuration.PSObject.Properties){[Environment]::SetEnvironmentVariable(('TOWNLIGHT_STATION_'+$item.Name),[string]$item.Value,'Process')}
$stationRoot=Join-Path $env:LOCALAPPDATA 'TownlightBetaStation'
$secret=[IO.File]::ReadAllText((Join-Path $stationRoot 'database-password.txt')).Trim()
$env:TOWNLIGHT_STATION_DATABASE_URL="postgresql+psycopg2://townlight_beta_station:${secret}@127.0.0.1:15432/townlight_beta_station"
if(Get-NetTCPConnection -State Listen -LocalPort 8756 -ErrorAction SilentlyContinue){throw 'Station port already in use'}
$service=Start-Process -FilePath $python -ArgumentList @('-I','-B','-m','townlight_station.cli','serve','--port','8756') -WindowStyle Hidden -PassThru -RedirectStandardOutput "$out\candidate-station-service.out" -RedirectStandardError "$out\candidate-station-service.err"
[ordered]@{pid=$service.Id;start=(Get-Process -Id $service.Id).StartTime.ToUniversalTime().ToString('o');executable=$python;purpose='Owned finite installed Station handoff regression';cancellation='Verify identity then terminate owned process or close owned guest'}|ConvertTo-Json|Set-Content -LiteralPath "$out\candidate-station-process.json" -Encoding utf8
$health=$null
for($n=0;$n -lt 30;$n++){if($service.HasExited){throw 'Station exited'};try{$health=Invoke-RestMethod 'http://127.0.0.1:8756/health' -TimeoutSec 2;break}catch{Start-Sleep -Seconds 1}}
if(!$health){throw 'Station health unavailable'}
$ffmpeg=Join-Path $installed.payload 'station\bin\ffmpeg.exe'
$source=Join-Path $env:TOWNLIGHT_STATION_DATA_ROOT 'ingest\candidate-finite.mp4'
if(Test-Path -LiteralPath $source){throw 'Finite media fixture exists'}
& $ffmpeg -nostdin -hide_banner -loglevel error -f lavfi -i 'testsrc2=size=320x180:rate=24' -f lavfi -i 'sine=frequency=600:sample_rate=48000' -t 3 -c:v libx264 -pix_fmt yuv420p -c:a aac $source
if($LASTEXITCODE){throw 'Synthetic finite media failed'}
$session=Get-Content -LiteralPath (Join-Path $env:LOCALAPPDATA 'CivicSuite\config\local-session.json') -Raw|ConvertFrom-Json
$headers=@{'X-Townlight-Session'=$session.session_hash};$base='http://127.0.0.1:8756'
$catalog=Invoke-RestMethod "$base/operator/catalog" -Headers $headers -TimeoutSec 30
$meeting=@($catalog.meetings|Where-Object title -EQ 'Fictional audit council meeting')
$request=@($catalog.requests|Where-Object summary -EQ 'Synthetic candidate linkage regression')
if($meeting.Count -ne 1 -or $request.Count -ne 1 -or !$catalog.can_capture -or !$catalog.can_attach){throw 'Meeting/Records catalog or authority missing'}
$agenda=@($catalog.agenda|Where-Object meeting_id -EQ $meeting[0].id)
if(!$agenda.Count){throw 'Meeting agenda missing'}
$body=@{meeting_id=$meeting[0].id;agenda_ids=@($agenda|Select-Object -ExpandProperty id);source_file='candidate-finite.mp4';idempotency_key='candidate-finite-806efe1'}|ConvertTo-Json
$queued=Invoke-RestMethod "$base/v1/recordings" -Headers $headers -Method Post -ContentType application/json -Body $body -TimeoutSec 30
$worker=Start-Process $python -ArgumentList @('-I','-B','-m','townlight_station.cli','worker','--once') -WindowStyle Hidden -PassThru -RedirectStandardOutput "$out\candidate-station-worker.out" -RedirectStandardError "$out\candidate-station-worker.err"
[ordered]@{pid=$worker.Id;start=(Get-Process -Id $worker.Id).StartTime.ToUniversalTime().ToString('o');executable=$python;purpose='Single finite synthetic media job';deadline_seconds=240}|ConvertTo-Json|Set-Content -LiteralPath "$out\candidate-station-worker.json" -Encoding utf8
if(!$worker.WaitForExit(240000)){throw 'Finite worker still running; inspect owned PID before cancellation'}
if($worker.ExitCode -ne 0){throw 'Finite worker failed'}
$record=Invoke-RestMethod "$base/v1/recordings/$($queued.id)" -Headers $headers -TimeoutSec 30
if($record.status -ne 'complete'){throw 'Recording incomplete'}
$media=Join-Path $out 'candidate-finite-recording.ts'
Invoke-WebRequest "$base/v1/recordings/$($queued.id)/content" -Headers $headers -OutFile $media -UseBasicParsing -TimeoutSec 30
$actual=(Get-FileHash -LiteralPath $media).Hash.ToLowerInvariant();if($actual -ne $record.details.sha256){throw 'Media SHA mismatch'}
$handoff=@{request_id=$request[0].id;recording_id=$queued.id;expected_sha256=$actual}|ConvertTo-Json
$attached=Invoke-RestMethod "$base/operator/handoff" -Headers $headers -Method Post -ContentType application/json -Body $handoff -TimeoutSec 180
[ordered]@{passed=$true;meeting=$meeting[0];request=$request[0];recording=$record;sha256=$actual;bytes=(Get-Item -LiteralPath $media).Length;attached=$attached;method='Fresh installed bundled service/API/worker, separate database/media, finite three-second synthetic source; subsequent native Records readback required'}|ConvertTo-Json -Depth 20|Set-Content -LiteralPath "$out\candidate-station-handoff.json" -Encoding utf8
