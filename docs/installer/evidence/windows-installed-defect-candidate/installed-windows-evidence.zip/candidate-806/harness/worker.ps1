$ErrorActionPreference='Stop'
$out='C:\TownlightEvidence'
if ($env:USERNAME -ne 'WDAGUtilityAccount') { throw 'Guest only' }
$started=[datetime]::UtcNow.ToString('o')
@{pid=$PID;started=$started;user=$env:USERNAME;computer=$env:COMPUTERNAME;memory=(Get-CimInstance Win32_OperatingSystem).TotalVisibleMemorySize} | ConvertTo-Json | Set-Content "$out/worker-start.json"
try { & 'C:\TownlightCandidate\install-only.ps1' } catch { $_ | Out-String | Set-Content "$out/install-worker-failure.txt" }
while (!(Test-Path 'C:\TownlightCandidate\STOP')) {
    @{pid=$PID;started=$started;heartbeat=[datetime]::UtcNow.ToString('o')} | ConvertTo-Json | Set-Content "$out/worker-heartbeat.json"
    foreach ($request in @(Get-ChildItem 'C:\TownlightCandidate\commands' -Filter '*.request.json' | Sort-Object Name)) {
        $id=$request.Name.Replace('.request.json','')
        if (Test-Path "$out/$id.result.json") { continue }
        $job=Get-Content -LiteralPath $request.FullName -Raw | ConvertFrom-Json
        $script=Join-Path 'C:\TownlightCandidate\commands' "$id.ps1"
        if ((Get-FileHash -LiteralPath $script).Hash -ne $job.sha256) { throw 'Job digest differs' }
        $when=[datetime]::UtcNow.ToString('o')
        $child=Start-Process powershell.exe -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',$script) -WindowStyle Hidden -PassThru -RedirectStandardOutput "$out/$id.stdout.txt" -RedirectStandardError "$out/$id.stderr.txt"
        @{id=$id;pid=$child.Id;started=$when;script_sha256=$job.sha256} | ConvertTo-Json | Set-Content "$out/$id.started.json"
        $finished=$child.WaitForExit([Math]::Min(1800000,[int]$job.timeout_seconds*1000))
        if (!$finished) { $child.Kill(); $child.WaitForExit() }
        @{id=$id;pid=$child.Id;started=$when;finished=[datetime]::UtcNow.ToString('o');timed_out=(!$finished);exit_code=$child.ExitCode;script_sha256=$job.sha256} | ConvertTo-Json | Set-Content "$out/$id.result.json"
    }
    Start-Sleep -Seconds 1
}
@{pid=$PID;stopped=[datetime]::UtcNow.ToString('o')} | ConvertTo-Json | Set-Content "$out/worker-stopped.json"
