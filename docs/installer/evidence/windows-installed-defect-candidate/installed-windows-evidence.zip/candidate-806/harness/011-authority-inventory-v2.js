(async()=>{
 const a=window.audit;const before=await a.native('get_app_state');
 if(!before.first_run.finished)return {blocked:'First-run setup is unfinished',before,records:a.records};
 await a.nav('health');
 const migration=await a.test('health/finish-records-migration',async()=>{await a.click('[data-supervisor-action="activate-records"]',{timeout:300000});},async()=>{await a.until(async()=>(await a.native('get_app_state')).domain_authority==='python-records',300000);return true;});
 const app=await a.native('get_app_state');const inventory={};const rows=[migration];
 for(const area of ['home','meetings','records','code','zoning','planning','permitting','inspections','notice','access','search','health','settings']){
   rows.push(await a.test('navigation/'+area,async()=>{await a.nav(area);inventory[area]={text:document.body.innerText,controls:a.inventory()};},r=>document.querySelector('.sidebar [data-area="'+area+'"]')?.getAttribute('aria-current')==='page'&&!/Authoritative city data is unavailable/.test(r.text)));
 }
 return {rows,app,inventory};
})()
