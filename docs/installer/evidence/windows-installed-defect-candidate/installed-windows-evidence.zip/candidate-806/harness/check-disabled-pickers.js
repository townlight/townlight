(async()=>{
 const a=window.audit,rows=[],app=()=>a.native('get_app_state');await a.click('[data-surface="IT/Admin"]');
 for(const [id,kind]of [['townlight_inspections',null],['townlight_permitting',null],['townlight_planning',null],['townlight_zoning',null],['townlight_code','code'],['townlight_meetings','meetings']]){
  await a.nav('settings');await a.sleep(5500);
  const disabled=await a.test('D5/disable-'+kind,()=>a.click('[data-module-action="disable-module"][data-module-id="'+id+'"]',{timeout:300000}),async()=>(await app()).modules.find(m=>m.id===id).enabled===false);rows.push(disabled);if(!disabled.pass)return{rows,app:await app()};
  if(kind){await a.ensureRuntime();await a.nav('records');rows.push(await a.test('D5/disabled-'+kind+'-picker-absent',async()=>{},()=>!document.querySelector('[data-'+kind+'-sources]')));}
 }
 for(const id of ['townlight_meetings','townlight_code','townlight_zoning','townlight_planning','townlight_permitting','townlight_inspections']){await a.nav('settings');await a.sleep(5500);rows.push(await a.test('D5/re-enable-'+id,()=>a.click('[data-module-action="enable-module"][data-module-id="'+id+'"]',{timeout:300000}),async()=>(await app()).modules.find(m=>m.id===id).enabled));}
 await a.ensureRuntime();await a.nav('records');rows.push(await a.test('D5/re-enabled-both-pickers-return',async()=>{},()=>!!document.querySelector('[data-code-sources]')&&!!document.querySelector('[data-meetings-sources]')));return{rows,app:await app()};
})()
