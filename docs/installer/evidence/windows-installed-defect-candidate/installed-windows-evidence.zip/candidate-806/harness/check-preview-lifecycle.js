(async()=>{
 const a=window.audit,f=a.fixture,rows=[],app=()=>a.native('get_app_state');
 a.ensureRuntime=async()=>{await a.nav('health');for(const id of ['postgres','python-services','task-queue']){const s=await app();if(!s.health.find(x=>x.id===id)?.ok)await a.click('[data-supervisor-action="start"][data-service-id="'+id+'"]',{timeout:300000});}await a.until(async()=>{try{await a.native('suite_domain_request',{request:{operation:'state'}});return true;}catch{return false;}},120000);};
 await a.click('[data-surface="IT/Admin"]');await a.nav('settings');
 const run=async(id,action,profile)=>{await a.sleep(5500);const row=await a.test('D7/'+action+'/'+id,()=>a.click('[data-module-action="'+action+'"][data-module-id="'+id+'"]',{timeout:300000}),async()=>{const s=await app(),m=s.modules.find(x=>x.id===id);return (action==='remove-module'?!m.installed:m.installed)&&s.module_selection.profile_id===profile;});rows.push(row);if(!row.pass)throw Error(row.id+': '+(row.error||document.querySelector('.action-result')?.textContent));};
 for(const [id,profile]of [['townlight_inspections','permitting-preview'],['townlight_permitting','planning-preview'],['townlight_planning','zoning-beta']])await run(id,'remove-module',profile);
 for(const [id,profile]of [['townlight_planning','planning-preview'],['townlight_permitting','permitting-preview'],['townlight_inspections','inspections-preview']])await run(id,'install-module',profile);
 await a.ensureRuntime();const restored=await a.native('suite_domain_request',{request:{operation:'state'}});const request=restored.records_requests.find(r=>r.request_id===f.records.request_id);
 rows.push(await a.test('D7/reinstalled-profile-retains-linked-Records',async()=>{},()=>!!request&&request.documents.length>=2));
 return {rows,request,app:await app()};
})()
