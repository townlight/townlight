(async()=>{
 const a=window.audit,f=a.fixture,rows=[];await a.nav('inspections');const status=()=>document.querySelector('[data-inspections-status]')?.textContent||'';
 const run=async(id,fn,check)=>{const row=await a.test(id,fn,check);rows.push(row);if(!row.pass)throw Error(id+': '+(row.error||status()));};
 await a.click('[data-inspections-action="new"]');
 for(const[k,v]of Object.entries({title:'Synthetic candidate citation removal',property_reference:'PRIVATE-CANDIDATE-PROPERTY',inspection_reference:'FIX-D4',dataset_kind:'fictional',inspector_notes:'PRIVATE inspection note',photo_observations:'Synthetic staff-observed fence condition',voice_notes:'PRIVATE voice note',assigned_to:'Synthetic inspector',staff_notes:'PRIVATE staff note',review_notes:'Synthetic inspector review',public_summary:'Synthetic public inspection workpaper'}))a.fill('[data-inspections-case] [name="'+k+'"]',v);
 a.file('[data-inspections-file]','candidate-original.txt','Synthetic unchanged original evidence, D4.','text/plain');await a.wait();
 await a.form('[data-inspections-search]',{query:f.codeIds.number});await a.click('[data-inspections-select="0"]');
 await run('D4/analyse-retained-original-with-citation',()=>a.click('[data-inspections-action="analyse"]'),()=>!!document.querySelector('[data-inspections-analysis] pre')&&!!document.querySelector('[data-inspections-remove="0"]'));
 await run('D4/save-analyzed-prior-revision',()=>a.click(document.querySelector('[data-inspections-case] button[type="submit"]')),()=>status().includes('Inspection draft saved'));
 await a.click('[data-inspections-action="review"]');
 await run('D4/remove-only-citation-clears-derived-analysis',()=>a.click('[data-inspections-remove="0"]'),()=>!document.querySelector('[data-inspections-remove]')&&!document.querySelector('[data-inspections-analysis] pre')&&!!document.querySelector('[data-inspections-remove-evidence]'));
 await run('D4/save-without-reanalysis',()=>a.click(document.querySelector('[data-inspections-case] button[type="submit"]')),()=>status().includes('Inspection draft saved'));
 await a.click('[data-inspections-action="cases"]');await a.click('[data-inspections-open="0"]');
 await run('D4/reopened-current-revision-keeps-original',async()=>{},()=>document.querySelector('[name="title"]').value==='Synthetic candidate citation removal'&&document.querySelector('[data-inspections-case]').textContent.includes('candidate-original.txt')&&!document.querySelector('[data-inspections-remove]'));
 await run('D4/prior-revision-retains-evidence-and-analysis',()=>a.click('[data-inspections-action="history"]'),()=>{const text=document.querySelector('[data-inspections-history]').textContent;return text.includes('candidate-original.txt')&&text.includes(f.codeIds.number)&&text.includes('cited_sections');});
 f.inspectionHistory=document.querySelector('[data-inspections-history]').textContent;return{rows,history:f.inspectionHistory};
})()
