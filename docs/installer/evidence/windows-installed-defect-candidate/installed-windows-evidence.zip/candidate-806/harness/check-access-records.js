(async()=>{
 const a=window.audit,f=a.fixture,rows=[],app=()=>a.native('get_app_state');
 const run=async(id,fn,check)=>{const row=await a.test(id,fn,check);rows.push(row);if(!row.pass)throw Error(id+': '+(row.error||'assertion failed'));};
 a.okWork=()=>!!document.querySelector('.action-result.saved')&&!document.querySelector('.action-result.blocked');
 const signIn=async()=>{await a.click('[data-surface="IT/Admin"]');await a.nav('settings');a.fill('[data-access-field="email"]',window.__auditAccount.email);a.fill('[data-access-field="passcode"]',window.__auditAccount.passcode);await a.click('[data-auth-action="sign-in"]');await a.until(async()=>(await app()).access.signed_in);await a.click('[data-surface="Staff"]');};
 const marker='PRIVATE-CANDIDATE-ACCESS-RESET-731';
 await a.nav('access');
 for(const[k,v]of Object.entries({accessTitle:marker,accessBody:'PRIVATE synthetic source text for sign-out regression.',accessHasAltText:false,accessLanguage:'EN'}))a.fill('[data-work-field="'+k+'"]',v);
 await run('D2/create-staff-review',()=>a.click('[data-work-action="accessibility-review"]'),async()=>{f.accessReview=(await a.native('access_domain_request',{request:{operation:'state'}})).reviews.find(r=>r.title===marker);return !!f.accessReview;});
 await run('D2/export-real-staff-review',async()=>{const button=[...document.querySelectorAll('[data-work-action="townlight_access-records-export"]')].find(e=>e.dataset.actionPayload.includes(f.accessReview.review_id));if(!button)throw Error('Review export control missing');await a.click(button);f.accessExportResult=document.querySelector('.action-result.saved')?.textContent;},()=>a.okWork()&&/written and verified at/i.test(f.accessExportResult));
 await run('D2/sign-out-clears-staff-export-and-draft',async()=>{await a.click('[data-auth-action="sign-out"]');await a.click('[data-surface="Resident/Public"]');await a.nav('records');},async()=>!(await app()).access.signed_in&&!document.body.innerText.includes('written and verified at')&&!document.body.innerText.includes(marker)&&!document.body.innerText.includes('C:\\Users\\WDAGUtilityAccount'));
 await signIn();await a.nav('access');
 await run('D2/sign-in-does-not-restore-unsaved-draft',async()=>{},()=>document.querySelector('[data-work-field="accessTitle"]').value==='');
 const pendingMarker='PRIVATE-INFLIGHT-CANDIDATE-731';
 a.fill('[data-work-field="accessTitle"]',pendingMarker);a.fill('[data-work-field="accessBody"]','PRIVATE in-flight synthetic source.');
 await run('D2/in-flight-result-cannot-repopulate-anonymous-state',async()=>{
   document.querySelector('[data-work-action="accessibility-review"]').click();f.inFlightControlStarted=!!document.querySelector('.action-result')?.textContent.match(/Working|Running|Saving/i)||document.querySelector('[data-work-action="accessibility-review"]')?.disabled;
   document.querySelector('[data-auth-action="sign-out"]').click();await a.sleep(2500);await a.wait();await a.click('[data-surface="Resident/Public"]');await a.nav('records');
 },async()=>f.inFlightControlStarted&&!(await app()).access.signed_in&&!document.body.innerText.includes(pendingMarker)&&!document.querySelector('.action-result.saved')&&!document.querySelector('.action-result.blocked'));
 await signIn();f.inFlightPersistedReview=(await a.native('access_domain_request',{request:{operation:'state'}})).reviews.find(r=>r.title===pendingMarker)||null;
 rows.push(await a.test('D2/in-flight-review-execution-readback',async()=>{},()=>!!f.inFlightPersistedReview));
 await a.nav('records');
 for(const[k,v]of Object.entries({requester:'Synthetic candidate requester',recordsSummary:'Synthetic candidate linkage regression',deadline:'2026-12-15',recordsDeadlineBasis:'Synthetic staff-selected deadline'}))a.fill('[data-work-field="'+k+'"]',v);
 await run('fixture/create-records-request',()=>a.click('[data-work-action="create-records-request"]'),async()=>{f.records=(await a.native('suite_domain_request',{request:{operation:'state'}})).records_requests.find(r=>r.summary==='Synthetic candidate linkage regression');return !!f.records?.request_id;});
 return {rows,fixture:f,app:await app()};
})()
