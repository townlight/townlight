"""Provision the disposable guest's dedicated Station database."""
from contextlib import closing
import json
import os
from pathlib import Path
import secrets
import sys

import psycopg2
from psycopg2 import sql
from townlight_station.boundary import Settings
from townlight_station.store import Store


def provision():
    evidence = Path(r"C:\TownlightEvidence")
    identity = json.loads((evidence / "candidate-installed.json").read_text(encoding="utf-8-sig"))
    expected = json.loads(Path(r"C:\TownlightCandidate\candidate-expected.json").read_text(encoding="utf-8-sig"))
    if identity["product_code"] != expected["product_code"] or identity["source_commit"] != expected["source_commit"]:
        raise RuntimeError("Unexpected candidate installation")
    payload = Path(identity["payload"])
    if payload != Path(identity["install_dir"]) / "_up_" / "runtime" / "payload":
        raise RuntimeError("Unexpected candidate payload")
    local = Path(os.environ["LOCALAPPDATA"])
    if local.parent.name != "AppData" or local.parent.parent.name != "WDAGUtilityAccount":
        raise RuntimeError("Expected the disposable Sandbox account")
    profile = local / "CivicSuite"
    station_root = local / "TownlightBetaStation"
    station_root.mkdir(exist_ok=True)
    secret_path = station_root / "database-password.txt"
    if not secret_path.exists():
        with secret_path.open("x", encoding="ascii") as handle:
            handle.write(secrets.token_hex(32))
    password = secret_path.read_text(encoding="ascii").strip()
    role = "townlight_beta_station"
    database = "townlight_beta_station"
    suite_password = (profile / "config/secrets/postgres-password.txt").read_text().strip()
    with closing(psycopg2.connect(host="127.0.0.1", port=15432, user="townlight",
                          dbname="postgres", password=suite_password, connect_timeout=5)) as admin:
        admin.autocommit = True
        with admin.cursor() as cursor:
            cursor.execute("SELECT rolcanlogin, rolsuper, rolcreatedb, rolcreaterole FROM pg_roles WHERE rolname=%s", (role,))
            existing = cursor.fetchone()
            if existing is None:
                cursor.execute(sql.SQL("CREATE ROLE {} LOGIN PASSWORD %s").format(sql.Identifier(role)), (password,))
            elif existing != (True, False, False, False):
                raise RuntimeError("Existing Station role has unexpected permissions")
            cursor.execute("SELECT pg_get_userbyid(datdba) FROM pg_database WHERE datname=%s", (database,))
            owner = cursor.fetchone()
            if owner is None:
                cursor.execute(sql.SQL("CREATE DATABASE {} OWNER {}").format(sql.Identifier(database), sql.Identifier(role)))
            elif owner != (role,):
                raise RuntimeError("Existing Station database owner differs")
    config = {
        "DATA_ROOT": str(station_root / "Data"),
        "DATABASE_URL": f"postgresql+psycopg2://{role}:{password}@127.0.0.1:15432/{database}",
        "SUITE_URL": "http://127.0.0.1:15480",
        "MEDIA_SOURCE": str(payload / "station/media-source"),
        "MEDIA_PYTHON": str(payload / "station/runtime/python.exe"),
        "MEDIA_RUNTIME": str(payload / "station/runtime"),
        "FFPROBE": str(payload / "station/bin/ffprobe.exe"),
    }
    os.environ.update({f"TOWNLIGHT_STATION_{key}": value for key, value in config.items()})
    settings = Settings.from_env()
    settings.initialize_storage()
    store = Store(settings.database_url)
    try:
        store.migrate()
    finally:
        store.engine.dispose()
    config.pop("DATABASE_URL")
    (evidence / "beta-station-database.json").write_text(json.dumps({
        "passed": True, "role": role, "database": database, "configuration": config,
    }, indent=2), encoding="utf-8")


if __name__ == "__main__":
    try:
        provision()
    except Exception as error:
        print(f"Station provisioning failed: {type(error).__name__}", file=sys.stderr)
        sys.exit(1)

