import os,json,hashlib
from pathlib import Path
import psycopg2
assert os.environ['USERNAME']=='WDAGUtilityAccount'
out=Path(r'C:\TownlightEvidence')
password=(Path(os.environ['LOCALAPPDATA'])/'CivicSuite/config/secrets/postgres-password.txt').read_text().strip()
con=psycopg2.connect(host='127.0.0.1',port=15432,user='townlight',dbname='townlight',password=password,connect_timeout=5)
con.set_session(readonly=True)
with con,con.cursor() as c:
 c.execute("SELECT revision_id,parent_revision,payload,sha256 FROM townlight_inspections.connected_revisions WHERE payload->>'title'=%s ORDER BY created_at",('Synthetic candidate citation removal',))
 rows=[dict(zip(('revision_id','parent_revision','payload','sha256'),row)) for row in c.fetchall()]
con.close()
for r in rows:
 r['hash_verified']=hashlib.sha256(json.dumps(r['payload'],sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()==r['sha256']
original_hash=hashlib.sha256(b'Synthetic unchanged original evidence, D4.').hexdigest()
checks={
 'at_least_three_immutable_revisions':len(rows)>=3,
 'all_revision_hashes_verify':all(r['hash_verified'] for r in rows),
 'original_retained_in_each_revision':all(any(e['filename']=='candidate-original.txt' and e['sha256']==original_hash for e in r['payload']['evidence']) for r in rows),
 'prior_analysis_and_citation_retained':any(r['payload'].get('analysis',{}).get('cited_sections') and r['payload']['linked_sources'] for r in rows[:-1] if r['payload'].get('analysis')),
 'current_analysis_and_citations_cleared':rows[-1]['payload'].get('analysis') is None and rows[-1]['payload']['linked_sources']==[],
 'parent_chain_intact':all(rows[i]['parent_revision']==rows[i-1]['revision_id'] for i in range(1,len(rows)))
}
(out/'inspection-revision-verification.json').write_text(json.dumps({'passed':all(checks.values()),'checks':checks,'revisions':rows,'method':'Read-only SELECT of actual installed guest database; canonical payload hashes independently recomputed'},indent=2),encoding='utf-8')
assert all(checks.values()), checks
