$ErrorActionPreference='Stop'
if ($env:COMPUTERNAME -eq 'SCOTT' -or !(Test-Path 'C:\TownlightCandidate\candidate-expected.json')) { throw 'Guest diagnostic only' }
$rows=@(Get-CimInstance Win32_Process | Where-Object Name -in @('msiexec.exe','powershell.exe') | Select-Object Name,ProcessId,CreationDate,KernelModeTime,UserModeTime,ReadTransferCount,WriteTransferCount,WorkingSetSize,CommandLine)
$os=Get-CimInstance Win32_OperatingSystem
[ordered]@{at=[datetime]::UtcNow.ToString('o');processes=$rows;free_memory_kib=$os.FreePhysicalMemory;free_c=(Get-PSDrive C).Free;installed_files=@(Get-ChildItem 'C:\Program Files\Townlight Windows Fix Candidate' -ErrorAction SilentlyContinue).Name} | ConvertTo-Json -Depth 5 | Set-Content 'C:\TownlightEvidence\install-progress.json'
