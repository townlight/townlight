(async()=>{
 const a=window.audit,f=a.fixture,rows=[],state=()=>a.native('suite_domain_request',{request:{operation:'state'}}),app=()=>a.native('get_app_state');
 await a.nav('records');
 if((await app()).module_selection.profile_id!=='inspections-preview')throw Error('Full Inspections preview required');
 const select=[...document.querySelectorAll('[data-select-work-record="recordsRequest"]')].find(e=>e.dataset.recordId===f.records.id);
 if(select)await a.click(select);
 for(const [kind,query]of [['meetings','Fictional audit'],['code',f.codeIds.number]]){
  const root='[data-'+kind+'-sources]';let before;
  rows.push(await a.test('D5/full-profile-'+kind+'-picker',async()=>{
   if(!document.querySelector(root))throw Error('Enabled picker missing');before=(await state()).records_requests.find(r=>r.request_id===f.records.request_id).documents.length;
   await a.form(root+' form',{query});await a.until(()=>!!document.querySelector(root+' [data-source-results] button'));
   await a.click(root+' [data-source-results] button');
   await a.until(async()=>(await state()).records_requests.find(r=>r.request_id===f.records.request_id).documents.length>before);
  },async()=>(await state()).records_requests.find(r=>r.request_id===f.records.request_id).documents.length===before+1));
 }
 return {rows,request:(await state()).records_requests.find(r=>r.request_id===f.records.request_id),app:await app()};
})()
