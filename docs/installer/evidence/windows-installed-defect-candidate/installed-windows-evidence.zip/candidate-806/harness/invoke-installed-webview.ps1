﻿param([Parameter(Mandatory)][string]$JavaScriptPath, [int]$TimeoutMinutes = 4)
$ErrorActionPreference = 'Stop'
$targets = @(Invoke-RestMethod 'http://127.0.0.1:9222/json/list' -TimeoutSec 5 | Where-Object {
    $_.type -eq 'page' -and $_.title -eq 'Townlight' -and $_.webSocketDebuggerUrl
})
if ($targets.Count -ne 1) { throw 'Expected one installed Townlight WebView target' }
$uri = [uri]$targets[0].webSocketDebuggerUrl
if ($uri.Scheme -ne 'ws' -or $uri.Host -ne '127.0.0.1' -or $uri.Port -ne 9222) {
    throw 'Unexpected WebView debugger endpoint'
}
$socket = [Net.WebSockets.ClientWebSocket]::new()
$timeout = [Threading.CancellationTokenSource]::new([TimeSpan]::FromMinutes($TimeoutMinutes))
try {
    $null = $socket.ConnectAsync($uri, $timeout.Token).GetAwaiter().GetResult()
    $enable=[Text.Encoding]::UTF8.GetBytes('{"id":2,"method":"Page.enable"}')
    $null=$socket.SendAsync([ArraySegment[byte]]::new($enable),[Net.WebSockets.WebSocketMessageType]::Text,$true,$timeout.Token).GetAwaiter().GetResult()
    $expression = [IO.File]::ReadAllText($JavaScriptPath)
    $command = @{id=1;method='Runtime.evaluate';params=@{
        expression=$expression;awaitPromise=$true;returnByValue=$true
    }} | ConvertTo-Json -Compress -Depth 6
    $bytes = [Text.Encoding]::UTF8.GetBytes($command)
    $null = $socket.SendAsync([ArraySegment[byte]]::new($bytes),[Net.WebSockets.WebSocketMessageType]::Text,$true,$timeout.Token).GetAwaiter().GetResult()
    $buffer = [byte[]]::new(16384)
    do {
        $message = [IO.MemoryStream]::new()
        try {
            do {
                $received = $socket.ReceiveAsync([ArraySegment[byte]]::new($buffer),$timeout.Token).GetAwaiter().GetResult()
                if ($received.MessageType -ne [Net.WebSockets.WebSocketMessageType]::Text) { throw 'Unexpected WebView message type' }
                $message.Write($buffer,0,$received.Count)
                if ($message.Length -gt 4194304) { throw 'WebView response exceeds evidence limit' }
            } until ($received.EndOfMessage)
            $reply = [Text.Encoding]::UTF8.GetString($message.ToArray()) | ConvertFrom-Json
        } finally { $message.Dispose() }
        if($reply.method -eq 'Page.javascriptDialogOpening') {
            $msg=$reply.params.message
            $allowed=@('Leaving will discard unsaved municipal tracking edits. Continue?','Leave unsaved inspection edits?','Record your staff review of this intake workpaper? This does not determine official completeness or approve a permit.','Record your inspector review of this workpaper? No official action will be issued.','Leave Planning with unsaved changes? Return to Planning to continue this draft. Signing out discards unsaved changes.','Leave unsaved intake edits?','Leave unsaved Permitting edits?','Leave unsaved Inspections edits?','Discard unsaved changes to this analysis? Saved revisions will be kept.','Discard unsaved municipal tracking edits? Saved revisions will be kept.')
            $accept=$msg -in $allowed
            @{at=[DateTime]::UtcNow.ToString('o');message=$msg;accepted=$accept}|ConvertTo-Json -Compress|Add-Content -Encoding UTF8 'C:\TownlightEvidence\dialogs.jsonl'
            $answer=@{id=3;method='Page.handleJavaScriptDialog';params=@{accept=$accept}}|ConvertTo-Json -Compress
            $null=$socket.SendAsync([ArraySegment[byte]]::new([Text.Encoding]::UTF8.GetBytes($answer)),[Net.WebSockets.WebSocketMessageType]::Text,$true,$timeout.Token).GetAwaiter().GetResult()
        }
    } until ($reply.id -eq 1)
    if ($reply.error -or $reply.result.exceptionDetails) {
        throw ($reply | ConvertTo-Json -Depth 12 -Compress)
    }
    $reply.result.result.value | ConvertTo-Json -Depth 20
} finally {
    $socket.Dispose()
    $timeout.Dispose()
}



