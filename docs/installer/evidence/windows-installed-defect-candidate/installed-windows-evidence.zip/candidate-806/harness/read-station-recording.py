import os
from pathlib import Path
import psycopg2
from contextlib import closing
secret=(Path(os.environ['LOCALAPPDATA'])/'TownlightBetaStation/database-password.txt').read_text().strip()
with closing(psycopg2.connect(host='127.0.0.1',port=15432,user='townlight_beta_station',dbname='townlight_beta_station',password=secret)) as conn:
    conn.set_session(readonly=True)
    with conn.cursor() as c:
        c.execute("SELECT id,status FROM station.recordings WHERE idempotency_key=%s",('candidate-finite-806efe1',))
        rows=c.fetchall()
        if len(rows)!=1 or rows[0][1]!='complete': raise RuntimeError(str(rows))
        print(rows[0][0])
