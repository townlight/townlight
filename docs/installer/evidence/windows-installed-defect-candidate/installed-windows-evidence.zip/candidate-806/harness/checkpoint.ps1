$ErrorActionPreference='Stop'
if ($env:USERNAME -ne 'WDAGUtilityAccount') { throw 'Guest only' }
& C:\TownlightCandidate\invoke-installed-webview.ps1 -JavaScriptPath C:\TownlightCandidate\checkpoint.js -TimeoutMinutes 2 | Set-Content -Encoding UTF8 C:\TownlightEvidence\checkpoint.json
