(async()=>{
 const a=window.audit,f=a.fixture??={},rows=[];await a.nav('code');f.codeInventory=a.inventory();
 const suffix=crypto.randomUUID().slice(0,8);f.codeIds={job:'audit-job-'+suffix,source:'audit-source-'+suffix,title:'audit-title-'+suffix,chapter:'audit-chapter-'+suffix,section:'audit-section-'+suffix,version:'audit-version-'+suffix,adopted:'audit-adopted-'+suffix,connection:'audit-connection-'+suffix,decision:'audit-decision-'+suffix,number:'97.'+suffix};const k=f.codeIds;
 const bundle={job_id:k.job,connector_type:'csv_bundle',source:{source_id:k.source,name:'Fictional audited Code',publisher:'Fictional clerk',source_type:'official_file_drop',source_category:'municipal_code',file_reference:'audit-code.json',source_owner:'Fictional clerk',retrieved_at:'2026-11-04T12:00:00Z',retrieval_method:'official_file_drop',is_official:true,status:'active'},titles:[{title_id:k.title,title_number:'97',title_name:'Fictional audit'}],chapters:[{chapter_id:k.chapter,title_id:k.title,chapter_number:'97.1',chapter_name:'Fictional audit'}],sections:[{section_id:k.section,chapter_id:k.chapter,section_number:k.number,section_heading:'Fictional audit ADU'}],versions:[{version_id:k.version,section_id:k.section,source_id:k.source,version_label:'Fictional base',body:'Fictional audit: accessory structures require staff review. Front setback is 10 feet.',effective_start:'2026-01-01',effective_end:'2026-11-03',status:'adopted',is_current:true}]};
 async function run(action,values={},check=r=>!!r,files={}){let result;rows.push(await a.test('code/'+action,async()=>{await a.form('form[data-code-action="'+action+'"]',values,files);const t=document.querySelector('[data-code-output]').textContent;const start=t.indexOf('{'),array=t.indexOf('[');let offset=start<0?array:array<0?start:Math.min(start,array);try{result=JSON.parse(t.slice(offset));}catch{throw Error(t);}},r=>!r.calls.some(c=>c.error)&&check(result)));return result;}
 f.codeImport=await run('importBundle',{},r=>r.status==='completed',{bundle:{name:'audit-code.json',text:JSON.stringify(bundle)}});
 await run('workspace',{},r=>JSON.stringify(r).includes(k.section));
 await run('sources',{},r=>JSON.stringify(r).includes(k.source));
 await run('lookup',{section:k.number,date:'2026-11-02'},r=>r.version?.version_id===k.version);
 await run('citation',{section:k.number,date:'2026-11-02'},r=>JSON.stringify(r).includes(k.source));
 await run('history',{sectionId:k.section},r=>JSON.stringify(r).includes(k.version));
 await run('search',{query:'Fictional audit'},r=>JSON.stringify(r).includes(k.section));
 f.codeExport=await run('exportSection',{section:k.number,date:'2026-11-02'},r=>JSON.stringify(r).includes(k.version));
 f.codeQuestion=await run('question',{question:'What does this fictional section require?',section:k.number,date:'2026-11-02'},r=>!!r.answer||!!r.classification||!!r.status);
 await run('importTree',{jobId:k.job},r=>JSON.stringify(r).includes(k.section));
 await run('importProvenance',{jobId:k.job},r=>JSON.stringify(r).includes(k.job)||JSON.stringify(r).includes(k.source));
 await run('connections',{},r=>Array.isArray(r));
 if(f.meeting?.id){
   f.codeProposal=await run('sendProposal',{id:k.connection,version_id:k.version,meeting_id:f.meeting.id,title:'Fictional ordinance proposal',ordinance_number:'AUDIT-2026',proposed_text:'Synthetic adopted ordinance text.'},r=>r.id===k.connection&&!!r.proposal?.agenda_item_id);
   await run('connection',{id:k.connection},r=>r.id===k.connection);
   rows.push(await a.test('link/code-open-in-meetings',async()=>{await a.click(document.querySelector('[data-code-links] button'));},r=>document.querySelector('.sidebar [data-area="meetings"]')?.getAttribute('aria-current')==='page'&&document.querySelector('[data-meetings-action="codeConnection"] [name="id"]')?.value===k.connection&&document.querySelector('[data-meetings-result]')?.textContent.includes(k.connection)));
   for(const action of ['codeConnections','codeConnection'])rows.push(await a.test('meetings/'+action,async()=>{await a.form('[data-meetings-action="'+action+'"]',action==='codeConnection'?{id:k.connection}:{});},r=>!r.calls.some(c=>c.error)&&document.querySelector('[data-meetings-result]')?.textContent.includes(k.connection)));
   rows.push(await a.test('meetings/recordCodeDecision',async()=>{await a.form('[data-meetings-action="recordCodeDecision"]',{id:k.connection,decision_id:k.decision,outcome:'adopted',decision_text:'Synthetic adopted ordinance text.',supporting_references:f.meeting.id});},r=>!r.calls.some(c=>c.error)&&document.querySelector('[data-meetings-result]')?.textContent.includes(k.decision)));
   await a.form('[data-meetings-action="codeConnection"]',{id:k.connection});
   rows.push(await a.test('link/meetings-open-in-code',async()=>{await a.click(document.querySelector('[data-meetings-links] button'));},r=>document.querySelector('.sidebar [data-area="code"]')?.getAttribute('aria-current')==='page'&&document.querySelector('[data-code-action="connection"] [name="id"]')?.value===k.connection&&document.querySelector('[data-code-output]')?.textContent.includes(k.decision)));
   f.codeCloseout=await run('closeConnection',{id:k.connection,decision_id:k.decision,version_id:k.adopted,source_id:k.source,version_label:'Fictional adopted',body:'Synthetic adopted ordinance text.',effective_start:'2026-11-04',is_current:true},r=>r.closeout?.version_id===k.adopted);
   f.codeAdoptedRead=await run('lookup',{section:k.number,date:'2026-11-05'},r=>r.version?.version_id===k.adopted&&r.version?.body==='Synthetic adopted ordinance text.');
 }
 return {rows,fixture:f};
})()
