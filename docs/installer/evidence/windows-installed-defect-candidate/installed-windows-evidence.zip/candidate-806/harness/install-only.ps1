param(
    [string]$InputRoot = 'C:\TownlightCandidate',
    [string]$EvidenceRoot = 'C:\TownlightEvidence'
)
$ErrorActionPreference = 'Stop'
if ($env:USERNAME -ne 'WDAGUtilityAccount') { throw 'Disposable Windows Sandbox guest only' }
$expectedPath = Join-Path $InputRoot 'candidate-expected.json'
if (!(Test-Path -LiteralPath $expectedPath -PathType Leaf)) { throw 'Exact candidate identity has not been supplied' }
$expected = Get-Content -LiteralPath $expectedPath -Raw | ConvertFrom-Json
foreach ($key in @('msi_sha256','exe_sha256','access_launcher_sha256')) {
    if ($expected.$key -notmatch '^[a-fA-F0-9]{64}$') { throw "Missing exact candidate hash: $key" }
}
$releasedHash = '8cebaea95fa62f582326a1a0c1af3cb54233c40dbb41d88324170eb1b3f25ade'
if ($expected.msi_sha256 -eq $releasedHash) { throw 'Expected a new unreleased candidate, not the released MSI' }
if ($expected.version -eq '1.7.0.1' -or $expected.version -notmatch '^\d+\.\d+\.\d+\.\d+$') { throw 'Distinct candidate MSI version required' }
if ($expected.product_code -notmatch '^\{[0-9a-fA-F-]{36}\}$') { throw 'Exact MSI product code required' }
if ($expected.product_name -notmatch '^Townlight [A-Za-z0-9 -]+$') { throw 'Explicit candidate product name required' }
if ($expected.source_commit -notmatch '^[a-fA-F0-9]{40}$') { throw 'Exact candidate source commit required' }
New-Item -ItemType Directory -Path $EvidenceRoot -Force | Out-Null
if (Test-Path -LiteralPath (Join-Path $EvidenceRoot 'candidate-installed.json')) { throw 'Install receipt already exists; do not overwrite evidence' }
Start-Transcript -Path (Join-Path $EvidenceRoot 'candidate-install-transcript.txt') -NoClobber
try {
    $arp = @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
             'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*')
    $before = @(Get-ItemProperty $arp -ErrorAction SilentlyContinue | Where-Object DisplayName -Like 'Townlight*')
    if ($before.Count -or (Test-Path -LiteralPath "$env:LOCALAPPDATA\CivicSuite")) { throw 'Guest is not a fresh Townlight installation' }
    $sourceMsi = Join-Path $InputRoot 'Townlight-Windows-Fix-Candidate-x64.msi'
    if ((Get-FileHash -LiteralPath $sourceMsi -Algorithm SHA256).Hash -ne $expected.msi_sha256) { throw 'Candidate MSI hash differs' }
    $signature = Get-AuthenticodeSignature -LiteralPath $sourceMsi
    if ($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -notmatch '^CN=Scott Converse(?:,|$)' -or !$signature.TimeStamperCertificate) {
        throw 'Candidate MSI lacks a valid Scott Converse signature and timestamp'
    }
    $localMsi = Join-Path $env:TEMP 'Townlight-Windows-Fix-Candidate-x64.msi'
    Copy-Item -LiteralPath $sourceMsi -Destination $localMsi
    if ((Get-FileHash -LiteralPath $localMsi -Algorithm SHA256).Hash -ne $expected.msi_sha256) { throw 'Guest-staged MSI hash differs' }
    $log = Join-Path $EvidenceRoot 'candidate-msiexec-install.log'
    $process = Start-Process msiexec.exe -ArgumentList @('/i', ('"' + $localMsi + '"'), '/qn', '/norestart', '/l*v', ('"' + $log + '"')) -WindowStyle Hidden -Wait -PassThru
    if ($process.ExitCode -ne 0) { throw "Candidate MSI installation failed: $($process.ExitCode)" }
    $entries = @(Get-ItemProperty $arp -ErrorAction SilentlyContinue | Where-Object DisplayName -EQ $expected.product_name)
    if ($entries.Count -ne 1 -or $entries[0].PSChildName -ne $expected.product_code -or $entries[0].DisplayVersion -ne $expected.version) {
        throw 'Installed registration differs from candidate identity'
    }
    $installDir = Join-Path $env:ProgramFiles $expected.product_name
    $exe = Join-Path $installDir 'townlight-desktop.exe'
    $payload = Join-Path $installDir '_up_\runtime\payload'
    $launcher = Join-Path $payload 'python\Scripts\townlight_access-db-status.exe'
    foreach ($item in @(@{path=$exe; hash=$expected.exe_sha256}, @{path=$launcher; hash=$expected.access_launcher_sha256})) {
        $fileSignature = Get-AuthenticodeSignature -LiteralPath $item.path
        if ((Get-FileHash -LiteralPath $item.path -Algorithm SHA256).Hash -ne $item.hash -or
            $fileSignature.Status -ne 'Valid' -or $fileSignature.SignerCertificate.Subject -notmatch '^CN=Scott Converse(?:,|$)' -or !$fileSignature.TimeStamperCertificate) {
            throw "Installed candidate bytes, signature or timestamp differ: $($item.path)"
        }
    }
    & $launcher --db-url 'sqlite:///:memory:' | Out-File (Join-Path $EvidenceRoot 'candidate-access-launcher.txt')
    if ($LASTEXITCODE) { throw 'Installed Access CLI failed' }
    [ordered]@{
        status='installed-identity-verified'; at=[datetime]::UtcNow.ToString('o'); source_commit=$expected.source_commit;
        product_code=$expected.product_code; version=$expected.version; msi_sha256=$expected.msi_sha256;
        desktop_sha256=$expected.exe_sha256; access_launcher_sha256=$expected.access_launcher_sha256;
        install_dir=$installDir; payload=$payload; workflow_acceptance='NOT YET RUN'; published=$false
    } | ConvertTo-Json | Set-Content -Encoding UTF8 -LiteralPath (Join-Path $EvidenceRoot 'candidate-installed.json')
} catch {
    $_ | Out-String | Set-Content -Encoding UTF8 -LiteralPath (Join-Path $EvidenceRoot 'candidate-install-failure.txt')
    throw
} finally { Stop-Transcript }
