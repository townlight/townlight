﻿$ErrorActionPreference='Stop'
if($env:USERNAME -ne 'WDAGUtilityAccount'){throw 'Guest only'}
$installed=Get-Content C:\TownlightEvidence\candidate-installed.json -Raw|ConvertFrom-Json
& (Join-Path $installed.payload 'python\python.exe') C:\TownlightCandidate\check-inspection-revisions.py
if($LASTEXITCODE){throw 'Inspection revision verification failed'}
