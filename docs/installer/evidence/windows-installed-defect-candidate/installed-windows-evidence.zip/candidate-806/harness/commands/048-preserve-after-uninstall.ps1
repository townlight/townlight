﻿$ErrorActionPreference='Stop'
if($env:USERNAME -ne 'WDAGUtilityAccount'){throw 'Wrong disposable guest account'}
$root='C:\Users\WDAGUtilityAccount\AppData\Local\CivicSuite'
$base='C:\Users\WDAGUtilityAccount\Documents\Townlight Backups'
$out='C:\TownlightEvidence\final-backup-manifests'
New-Item -ItemType Directory -Path $out -Force|Out-Null
$rows=@()
foreach($dir in Get-ChildItem -LiteralPath $base -Directory){$manifest=Join-Path $dir.FullName 'backup-manifest.json';if(Test-Path -LiteralPath $manifest){$copy=Join-Path $out ($dir.Name+'.json');Copy-Item -LiteralPath $manifest -Destination $copy;$sourceHash=(Get-FileHash -LiteralPath $manifest).Hash;$copyHash=(Get-FileHash -LiteralPath $copy).Hash;if($sourceHash -ne $copyHash){throw 'Manifest copy differs'};$rows+=@{backup=$dir.FullName;manifest_sha256=$sourceHash;preserved=$copy;bytes=(@(Get-ChildItem -LiteralPath $dir.FullName -Recurse -File)|Measure-Object Length -Sum).Sum}}}
$old=@(Get-ChildItem -LiteralPath $root -Force -Directory|Where-Object Name -Like '.townlight-restore-*'|ForEach-Object{@{path=$_.FullName;files=@(Get-ChildItem -LiteralPath $_.FullName -File -Recurse|Select-Object FullName,Length)}})
@{at=[datetime]::UtcNow.ToString('o');backups=$rows;restore_swap_folders=$old;model_cache_staged_outside_profile=Test-Path -LiteralPath C:\TownlightAuditModelCache;synthetic_cache_disposition='Disposable guest fixture; removed when owned Sandbox closes, not user model cache'}|ConvertTo-Json -Depth 7|Set-Content -Encoding UTF8 C:\TownlightEvidence\final-after-uninstall-evidence.json

$installed=Get-Content -LiteralPath C:\TownlightEvidence\candidate-installed.json -Raw|ConvertFrom-Json
@{at=[datetime]::UtcNow.ToString('o');files=@(Get-ChildItem -LiteralPath $installed.install_dir -File -Recurse -ErrorAction SilentlyContinue|Select-Object FullName,Length);processes=@(Get-CimInstance Win32_Process|Where-Object {$_.ExecutablePath -and $_.ExecutablePath.StartsWith($installed.install_dir,[StringComparison]::OrdinalIgnoreCase)}|Select-Object ProcessId,ExecutablePath)}|ConvertTo-Json -Depth 6|Set-Content -LiteralPath C:\TownlightEvidence\final-guest-state.json -Encoding utf8
