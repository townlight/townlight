﻿$ErrorActionPreference='Stop'
if($env:USERNAME -ne 'WDAGUtilityAccount'){throw 'Disposable guest only'}
$out='C:\TownlightEvidence'
$done=Get-Content -LiteralPath "$out\045-finish-restart-readback.json" -Raw|ConvertFrom-Json
if(!$done.passed){throw 'Restart proof incomplete'}
$installed=Get-Content -LiteralPath "$out\candidate-installed.json" -Raw|ConvertFrom-Json
$exe=Join-Path $installed.install_dir 'townlight-desktop.exe'
$sha=(Get-FileHash -LiteralPath $exe).Hash
$sig=Get-AuthenticodeSignature -LiteralPath $exe
if($sha -ne $installed.desktop_sha256 -or $sig.Status -ne 'Valid'){throw 'Installed binary changed'}
[ordered]@{passed=$true;sha256=$sha;publisher=$sig.SignerCertificate.Subject;timestamp=$sig.TimeStamperCertificate.Subject;at=[datetime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content -LiteralPath "$out\final-installed-binary.json" -Encoding utf8
$owned=Get-Content -LiteralPath "$out\candidate-station-process.json" -Raw|ConvertFrom-Json
$process=Get-Process -Id $owned.pid -ErrorAction SilentlyContinue
if($process){if($process.Path -ne $owned.executable -or $process.StartTime.ToUniversalTime().ToString('o') -ne $owned.start){throw 'Station PID identity changed'};Stop-Process -Id $process.Id;$process.WaitForExit(10000)|Out-Null}
[ordered]@{pid=$owned.pid;stopped=!(Get-Process -Id $owned.pid -ErrorAction SilentlyContinue);at=[datetime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content -LiteralPath "$out\candidate-station-stopped.json" -Encoding utf8
$js=Join-Path $env:TEMP 'candidate-prepare-uninstall.js'
[IO.File]::WriteAllText($js,'(async()=>{const a=window.audit;await a.nav("health");await a.sleep(6000);const row=await a.test("uninstall/prepare-final-backup-and-profile-removal",()=>a.click("[data-supervisor-action=\"uninstall\"]",{timeout:300000}),()=>!document.querySelector(".action-result.blocked"));return{passed:row.pass,row,app:await a.native("get_app_state"),results:[...document.querySelectorAll(".action-result")].map(e=>e.textContent)};})()')
& C:\TownlightCandidate\invoke-installed-webview.ps1 -JavaScriptPath $js -TimeoutMinutes 8|Set-Content -LiteralPath "$out\candidate-prepare-uninstall.json" -Encoding utf8
