﻿$ErrorActionPreference='Stop'
& 'C:\TownlightCandidate\invoke-installed-webview.ps1' -JavaScriptPath 'C:\TownlightCandidate\commands\010-setup.js' -TimeoutMinutes 25 | Set-Content -Encoding UTF8 'C:\TownlightEvidence\010-setup.json'
