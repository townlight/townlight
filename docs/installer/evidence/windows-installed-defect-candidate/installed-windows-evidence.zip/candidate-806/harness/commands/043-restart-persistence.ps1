﻿$ErrorActionPreference='Stop'
& 'C:\TownlightCandidate\invoke-installed-webview.ps1' -JavaScriptPath 'C:\TownlightCandidate\commands\043-restart-persistence.js' -TimeoutMinutes 25 | Set-Content -Encoding UTF8 'C:\TownlightEvidence\043-restart-persistence.json'
