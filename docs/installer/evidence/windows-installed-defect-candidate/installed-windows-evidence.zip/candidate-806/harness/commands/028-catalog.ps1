﻿$ErrorActionPreference='Stop'
& 'C:\TownlightCandidate\invoke-installed-webview.ps1' -JavaScriptPath 'C:\TownlightCandidate\commands\028-catalog.js' -TimeoutMinutes 25 | Set-Content -Encoding UTF8 'C:\TownlightEvidence\028-catalog.json'
