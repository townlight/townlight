﻿$ErrorActionPreference='Stop'
if($env:USERNAME -ne 'WDAGUtilityAccount'){throw 'Disposable guest only'}
$out='C:\TownlightEvidence'
$installed=Get-Content -LiteralPath "$out\candidate-installed.json" -Raw|ConvertFrom-Json
$python=Join-Path $installed.payload 'python\python.exe'
$session=Get-Content -LiteralPath (Join-Path $env:LOCALAPPDATA 'CivicSuite\config\local-session.json') -Raw|ConvertFrom-Json
$headers=@{'X-Townlight-Session'=$session.session_hash};$base='http://127.0.0.1:8756'
$catalog=Invoke-RestMethod "$base/operator/catalog" -Headers $headers -TimeoutSec 30
$meeting=@($catalog.meetings|Where-Object title -EQ 'Fictional audit council meeting')
$request=@($catalog.requests|Where-Object summary -EQ 'Synthetic candidate linkage regression')
if($meeting.Count -ne 1 -or $request.Count -ne 1){throw 'Fixture missing'}
$recordId=& $python -I -B C:\TownlightCandidate\read-station-recording.py
if($LASTEXITCODE){throw 'Persisted recording identity read failed'}
$queued=@{id=$recordId.Trim()}
$record=Invoke-RestMethod "$base/v1/recordings/$($queued.id)" -Headers $headers -TimeoutSec 30
if($record.status -ne 'complete'){throw 'Recording incomplete'}
$media=Join-Path $out 'candidate-finite-recording.ts'
Invoke-WebRequest "$base/v1/recordings/$($queued.id)/content" -Headers $headers -OutFile $media -UseBasicParsing -TimeoutSec 30
$actual=(Get-FileHash -LiteralPath $media).Hash.ToLowerInvariant();if($actual -ne $record.details.sha256){throw 'Media SHA mismatch'}
$handoff=@{request_id=$request[0].id;recording_id=$queued.id;expected_sha256=$actual}|ConvertTo-Json
$attached=Invoke-RestMethod "$base/operator/handoff" -Headers $headers -Method Post -ContentType application/json -Body $handoff -TimeoutSec 180
[ordered]@{passed=$true;meeting=$meeting[0];request=$request[0];recording=$record;sha256=$actual;bytes=(Get-Item -LiteralPath $media).Length;attached=$attached;method='Fresh installed bundled service/API/worker, separate database/media, finite three-second synthetic source; subsequent native Records readback required'}|ConvertTo-Json -Depth 20|Set-Content -LiteralPath "$out\candidate-station-handoff.json" -Encoding utf8
