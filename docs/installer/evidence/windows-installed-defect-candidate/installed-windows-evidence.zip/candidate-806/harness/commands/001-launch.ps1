﻿$ErrorActionPreference = 'Stop'
if ($env:USERNAME -ne 'WDAGUtilityAccount') { throw 'Sandbox guest only' }
$out = 'C:\TownlightEvidence'
$installed = Get-Content -LiteralPath "$out\candidate-installed.json" -Raw | ConvertFrom-Json
if ($installed.status -ne 'installed-identity-verified') { throw 'Exact candidate installation is not verified' }
$exe = Join-Path $installed.install_dir 'townlight-desktop.exe'
if ((Get-FileHash -LiteralPath $exe).Hash -ne $installed.desktop_sha256 -or (Get-AuthenticodeSignature -LiteralPath $exe).Status -ne 'Valid') { throw 'Installed executable changed' }
if (Get-CimInstance Win32_Process | Where-Object ExecutablePath -EQ $exe) { throw 'Installed app already running; recover its existing WebView instead' }
if (Get-NetTCPConnection -LocalPort 9222 -State Listen -ErrorAction SilentlyContinue) { throw 'Guest debug port already in use' }
$debugPolicy = 'HKLM:\SOFTWARE\Policies\Microsoft\Edge\WebView2\AdditionalBrowserArguments'
New-Item -Path $debugPolicy -Force | Out-Null
New-ItemProperty -LiteralPath $debugPolicy -Name 'townlight-desktop.exe' -PropertyType String -Value '--remote-debugging-port=9222' -Force | Out-Null
$env:WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS = '--remote-debugging-port=9222'
$env:TOWNLIGHT_STATION_URL = 'http://127.0.0.1:8756'
$app = Start-Process -FilePath $exe -WorkingDirectory $installed.install_dir -PassThru
$deadline = (Get-Date).AddSeconds(75)
$page = $null
while (!$page -and (Get-Date) -lt $deadline) {
    $app.Refresh()
    if ($app.HasExited) { throw "Installed candidate exited: $($app.ExitCode)" }
    try {
        $pages = @(Invoke-RestMethod 'http://127.0.0.1:9222/json/list' -TimeoutSec 2)
        $page = $pages | Where-Object { $_.type -eq 'page' -and $_.title -eq 'Townlight' -and $_.webSocketDebuggerUrl } | Select-Object -First 1
    } catch {}
    if (!$page) { Start-Sleep -Seconds 1 }
}
if (!$page) { throw 'Installed candidate WebView did not open' }
[ordered]@{pid=$app.Id;started=$app.StartTime.ToUniversalTime().ToString('o');exe=$exe;page=$page;installed_source=$installed.source_commit;configuration=@{TOWNLIGHT_STATION_URL=$env:TOWNLIGHT_STATION_URL};station_note='Explicit separate Station setup per installed manual guidance; not automatic provisioning'} |
    ConvertTo-Json -Depth 5 | Set-Content -LiteralPath "$out\candidate-launched.json" -Encoding utf8
