﻿$ErrorActionPreference='Stop'
if($env:USERNAME -ne 'WDAGUtilityAccount'){throw 'Disposable guest only'}
$root=Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'Townlight Backups'
$before=@(Get-ChildItem -LiteralPath $root -Directory | Select-Object -ExpandProperty Name | Sort-Object)
& C:\TownlightCandidate\invoke-installed-webview.ps1 -JavaScriptPath C:\TownlightCandidate\check-removal-preflight.js -TimeoutMinutes 6 | Set-Content -LiteralPath C:\TownlightEvidence\removal-preflight-ui.json -Encoding utf8
$after=@(Get-ChildItem -LiteralPath $root -Directory | Select-Object -ExpandProperty Name | Sort-Object)
[ordered]@{passed=(($before -join '|') -eq ($after -join '|'));before=$before;after=$after;method='Independent guest backup-directory inventory around actual installed refusal control'} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath C:\TownlightEvidence\removal-preflight-backup-inventory.json -Encoding utf8
