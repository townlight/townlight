(async()=>{
 const a=window.audit,f=a.fixture,rows=[];
 const priorAttempt=a.records.filter(r=>r.id.startsWith('D4/'));
 rows.push(await a.test('D4/reopened-current-revision-retains-original-correct-scope',async()=>{},()=>
  document.querySelector('[data-inspections-case] [name="title"]').value==='Synthetic candidate citation removal'&&
  [...document.querySelectorAll('[data-inspections-remove-evidence]')].length===1&&
  document.querySelector('[data-inspections-remove-evidence]').parentElement.textContent.includes('candidate-original.txt')&&
  !document.querySelector('[data-inspections-remove]')&&!document.querySelector('[data-inspections-analysis] pre')));
 rows.push(await a.test('D4/prior-revision-retains-evidence-and-analysis',()=>a.click('[data-inspections-action="history"]'),()=>{
  const text=document.querySelector('[data-inspections-history]').textContent;return text.includes('candidate-original.txt')&&text.includes(f.codeIds.number)&&text.includes('cited_sections');
 }));
 f.inspectionHistory=document.querySelector('[data-inspections-history]').textContent;
 return {rows,history:f.inspectionHistory,priorAttempt,correction:'Original-evidence section is a sibling of the case form; prior harness incorrectly searched only form text.'};
})()
