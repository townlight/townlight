(async () => {
  const a = window.audit, f = a.fixture, rows = [];
  if (!f?.codeIds || !f?.archive?.id) throw Error('Create actual Code and public archived Meeting fixtures first');
  const role = {email: 'fix-code-staff@example.invalid', passcode: 'Synthetic-Windows-fix-2026!'};
  const app = () => a.native('get_app_state');
  const settings = async () => { await a.click('[data-surface="IT/Admin"]'); await a.nav('settings'); };
  const signIn = async (email, passcode) => {
    await settings(); a.fill('[data-access-field="email"]', email); a.fill('[data-access-field="passcode"]', passcode);
    await a.click('[data-auth-action="sign-in"]');
    await a.until(async () => (await app()).access?.signed_in === true);
  };
  await settings();
  for (const [key, value] of Object.entries({userName:'Synthetic Code-only regression staff', userEmail:role.email, userRole:'code-staff', userPasscode:role.passcode})) {
    a.fill('[data-user-field="' + key + '"]', value);
  }
  await a.click('[data-auth-action="create-user"]');
  await a.click('[data-auth-action="sign-out"]');
  await signIn(role.email, role.passcode);
  rows.push(await a.test('D1/code-only-role', async () => {}, async () => (await app()).access.role === 'code-staff'));
  await a.click('[data-surface="Staff"]'); await a.nav('code');
  rows.push(await a.test('D1/code-only-installed-lookup', async () => {
    await a.form('[data-code-action="lookup"]', {section:f.codeIds.number, date:'2026-11-05'});
    await a.until(() => document.querySelector('[data-code-output]')?.textContent.includes(f.codeIds.adopted));
  }, () => !document.querySelector('main').textContent.includes('Records service is unavailable') &&
      document.querySelector('[data-code-output]').textContent.includes(f.codeIds.adopted)));
  let recordsError;
  rows.push(await a.test('D1/records-remains-denied', async () => {
    try { await a.native('records_domain_request', {request:{operation:'state'}}); }
    catch (error) { recordsError = error; }
  }, () => !!recordsError && /denied|staff|authoriz|permission/i.test(JSON.stringify(recordsError))));
  const projection = await a.native('suite_domain_request', {request:{operation:'state'}});
  rows.push(await a.test('D1/no-private-Records-or-Access-projection', async () => {}, () =>
    Array.isArray(projection.records_requests) && projection.records_requests.length === 0 &&
    Array.isArray(projection.access?.reviews) && projection.access.reviews.length === 0));
  await settings(); await a.click('[data-auth-action="sign-out"]');
  await a.click('[data-surface="Resident/Public"]'); await a.nav('meetings');
  rows.push(await a.test('D3/anonymous-meetings-archive-search', async () => {
    await a.form('[data-published-action="meetings-search"]', {query:'Fictional audit'});
    await a.until(() => !!document.querySelector('[data-published-id="' + f.archive.id + '"]'));
  }, () => !document.querySelector('[data-meetings-create]') && !!document.querySelector('[data-published-id="' + f.archive.id + '"]')));
  rows.push(await a.test('D3/anonymous-meeting-agenda-packet-minutes', async () => {
    await a.click('[data-published-id="' + f.archive.id + '"]');
    await a.until(() => document.querySelectorAll('[data-published-output] pre').length === 3);
  }, () => [...document.querySelectorAll('[data-published-output] pre')].every(node => node.textContent.trim().length > 0) &&
      !document.querySelector('[data-published-output]').textContent.includes('PRIVATE-')));
  await a.nav('code');
  for (const [operation, values, expected] of [
    ['code-search', {query:'Fictional audit'}, f.codeIds.section],
    ['code-lookup', {section_number:f.codeIds.number, as_of:'2026-11-05'}, f.codeIds.adopted],
    ['code-citation', {section_number:f.codeIds.number, as_of:'2026-11-05'}, f.codeIds.source],
    ['code-export', {section_number:f.codeIds.number, as_of:'2026-11-05'}, f.codeIds.adopted],
    ['code-answer', {query:'What does this fictional section require?', section_number:f.codeIds.number}, f.codeIds.number]
  ]) {
    rows.push(await a.test('D3/anonymous-' + operation, async () => {
      await a.form('[data-published-action="' + operation + '"]', values);
      await a.until(() => !document.querySelector('[data-published-output]').textContent.startsWith('Loading'));
    }, () => document.querySelector('[data-published-output]').textContent.includes(expected) &&
        !document.querySelector('[data-code-action="importBundle"]')));
  }
  let staffWriteError;
  rows.push(await a.test('D3/anonymous-native-staff-write-denied', async () => {
    try { await a.native('code_domain_request', {request:{operation:'import', payload:{}}}); }
    catch (error) { staffWriteError = error; }
  }, () => !!staffWriteError && /denied|staff|authoriz|permission/i.test(JSON.stringify(staffWriteError))));
  await signIn(window.__auditAccount.email, window.__auditAccount.passcode);
  await a.click('[data-surface="Staff"]');
  return {rows,recordsError,staffWriteError,projection,app:await app()};
})()
