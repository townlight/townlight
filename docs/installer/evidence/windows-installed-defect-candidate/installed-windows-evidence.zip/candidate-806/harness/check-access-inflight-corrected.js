(async()=>{
 const a=window.audit,f=a.fixture,rows=[],app=()=>a.native('get_app_state');
 const priorAttempt={rows:a.records.filter(r=>r.id.startsWith('D2/')),inFlightControlStarted:f.inFlightControlStarted};
 const signIn=async()=>{await a.click('[data-surface="IT/Admin"]');await a.nav('settings');a.fill('[data-access-field="email"]',window.__auditAccount.email);a.fill('[data-access-field="passcode"]',window.__auditAccount.passcode);await a.click('[data-auth-action="sign-in"]');await a.until(async()=>(await app()).access.signed_in);await a.click('[data-surface="Staff"]');};
 await signIn();await a.nav('access');
 const marker='PRIVATE-INFLIGHT-CONFIRMED-731';
 a.fill('[data-work-field="accessTitle"]',marker);a.fill('[data-work-field="accessBody"]','PRIVATE synthetic source for a confirmed in-flight save.');
 rows.push(await a.test('D2/confirmed-in-flight-result-cannot-repopulate-anonymous-state',async()=>{
   document.querySelector('[data-work-action="accessibility-review"]').click();
   const confirm=document.querySelector('[data-review-confirm]');if(!confirm)throw Error('Expected human-review confirmation before dispatch');
   confirm.click();
   f.confirmedInFlightStarted=document.querySelector('[data-work-action="accessibility-review"]')?.disabled===true;
   document.querySelector('[data-auth-action="sign-out"]').click();
   await a.sleep(4000);await a.click('[data-surface="Resident/Public"]');await a.nav('records');
 },async()=>f.confirmedInFlightStarted&&!(await app()).access.signed_in&&!document.body.innerText.includes(marker)&&!document.querySelector('.action-result.saved')&&!document.querySelector('.action-result.blocked')));
 if(!rows[0].pass)throw Error('Confirmed in-flight test failed '+JSON.stringify(rows[0]));
 await signIn();f.inFlightPersistedReview=(await a.native('access_domain_request',{request:{operation:'state'}})).reviews.find(r=>r.title===marker)||null;
 await a.nav('records');
 for(const[k,v]of Object.entries({requester:'Synthetic candidate requester',recordsSummary:'Synthetic candidate linkage regression',deadline:'2026-12-15',recordsDeadlineBasis:'Synthetic staff-selected deadline'}))a.fill('[data-work-field="'+k+'"]',v);
 rows.push(await a.test('fixture/create-records-request',()=>a.click('[data-work-action="create-records-request"]'),async()=>{f.records=(await a.native('suite_domain_request',{request:{operation:'state'}})).records_requests.find(r=>r.summary==='Synthetic candidate linkage regression');return !!f.records?.request_id;}));
 return {rows,fixture:f,priorAttempt,correction:'Earlier harness clicked Run Review but omitted its human-review confirmation, so no operation was dispatched; confirmed pending control required here.'};
})()
