(async()=>{
 const a=window.audit,rows=[];await a.click('[data-surface="IT/Admin"]');await a.nav('settings');
 rows.push(await a.test('D9/installed-profile-copy',async()=>{},()=>!document.querySelector('main').textContent.match(/Explicit unsigned|Not a published release|not available in this release yet|current 1\.0 package/)));
 const row=[...document.querySelectorAll('article')].find(e=>e.textContent.includes('Separate Station backup:'));
 const manual=document.querySelector('a[href="https://townlight.github.io/manuals/station.html"]');
 rows.push(await a.test('D9/Station-separate-service-guidance',async()=>{},()=>!!manual&&document.body.innerText.includes('Bundled separate service')&&document.body.innerText.includes('Separate Station backup:')&&document.body.innerText.includes('Separate Station database')&&document.body.innerText.includes('Separate Station media directory')&&document.body.innerText.includes('TOWNLIGHT_STATION_URL')&&!row?.textContent.includes('notice export')));
 return {rows,station:row?.textContent,manual:manual?.outerHTML,inventory:a.inventory()};
})()
