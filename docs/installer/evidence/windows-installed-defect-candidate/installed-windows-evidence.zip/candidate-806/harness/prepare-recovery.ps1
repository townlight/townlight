$ErrorActionPreference='Stop'
if($env:USERNAME -ne 'WDAGUtilityAccount'){throw 'Disposable guest only'}
$root=Join-Path $env:LOCALAPPDATA 'CivicSuite\Data'
$dir=Join-Path $root 'files\candidate-recovery'
New-Item -ItemType Directory -Path $dir -Force | Out-Null
$sentinel=Join-Path $dir 'a-sentinel.txt';$locked=Join-Path $dir 'z-locked.txt'
if((Test-Path -LiteralPath $sentinel) -or (Test-Path -LiteralPath $locked)){throw 'Recovery fixture already exists'}
[IO.File]::WriteAllText($sentinel,'Synthetic ORIGINAL candidate sentinel.')
[IO.File]::WriteAllText($locked,'Synthetic ORIGINAL locked-last sentinel.')
$modelDir=Join-Path $root 'models';New-Item -ItemType Directory -Path $modelDir -Force | Out-Null
$model=Join-Path $modelDir 'candidate-cache-marker.txt';if(Test-Path -LiteralPath $model){throw 'Cache fixture exists'}
[IO.File]::WriteAllText($model,'Synthetic cache ORIGINAL, not an AI model.')
[ordered]@{sentinel=$sentinel;locked=$locked;model=$model;exports=(Join-Path $root 'exports');original_sha256=(Get-FileHash -LiteralPath $sentinel).Hash;locked_original_sha256=(Get-FileHash -LiteralPath $locked).Hash;model_original_sha256=(Get-FileHash -LiteralPath $model).Hash} | ConvertTo-Json | Set-Content -LiteralPath C:\TownlightEvidence\recovery-fixture.json -Encoding utf8
